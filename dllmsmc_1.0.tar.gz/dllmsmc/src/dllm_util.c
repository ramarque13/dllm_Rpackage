#include "dllm.h"
int dllm_sim_x_lin(int i_nT,double *i_y,double tau0,
		   double alpha,double phi,double tau,const gsl_rng *i_r,
		   gsl_vector *o_x)
{
  int     t;
  double  xpred,Ppred,S,K,A,mu,P,sig2,sig02;
  gsl_vector *xhat, *Phat;
  
  xhat = gsl_vector_alloc(i_nT);
  Phat = gsl_vector_alloc(i_nT);

  sig02 = G_ONE/tau0;
  sig2 = G_ONE/tau;
  // Run Kalman simulator
  xpred = G_ZERO;
  Ppred = sig02;
  S = Ppred+G_ONE;
  K = Ppred/S;
  gsl_vector_set(Phat,0,(G_ONE-K)*Ppred);
  gsl_vector_set(xhat,0,xpred + K*(i_y[0]-xpred));
  for(t=1;t<i_nT;t++)
    {
      xpred = alpha+phi*(gsl_vector_get(xhat,t-1)-alpha);
      Ppred = phi*phi*gsl_vector_get(Phat,t-1)+sig2;
      S = Ppred+G_ONE;
      K = Ppred/S;
      gsl_vector_set(Phat,t,(G_ONE-K)*Ppred);
      gsl_vector_set(xhat,t,xpred + K*(i_y[t]-xpred));
    }
  gsl_vector_set(o_x,i_nT-1,gsl_vector_get(xhat,i_nT-1)+
		 gsl_ran_gaussian(i_r,sqrt(gsl_vector_get(Phat,i_nT-1))));
  for(t=i_nT-2;t>=0;t--)
    {
      xpred = alpha+phi*(gsl_vector_get(xhat,t)-alpha);
      Ppred = phi*phi*gsl_vector_get(Phat,t)+sig2;
      A = gsl_vector_get(Phat,t)*phi/Ppred;
      mu = gsl_vector_get(xhat,t)+A*(gsl_vector_get(o_x,t+1)-xpred);
      P = gsl_vector_get(Phat,t) * sig2/Ppred;
      gsl_vector_set(o_x,t,mu + sqrt(P)*gsl_ran_ugaussian(i_r));
    }

  gsl_vector_free(xhat);
  gsl_vector_free(Phat);
  return(0);
}

int dllm_calc_suff(int nT,int p,gsl_vector *i_x,double *o_XX,gsl_vector *o_XZ,gsl_matrix *o_ZZ)
{
  int     i,j,t;

  *o_XX = G_ZERO;
  for(i=0;i<p;i++)
    {
      gsl_vector_set(o_XZ,i,G_ZERO);
      for(j=0;j<p;j++)
	gsl_matrix_set(o_ZZ,i,j,G_ZERO);
    }
  for(t=1;t<nT;t++)
    {
      *o_XX += gsl_vector_get(i_x,t)*gsl_vector_get(i_x,t);
      gsl_vector_set(o_XZ,0,gsl_vector_get(o_XZ,0)+gsl_vector_get(i_x,t));
      gsl_vector_set(o_XZ,1,gsl_vector_get(o_XZ,1)+gsl_vector_get(i_x,t)*gsl_vector_get(i_x,t-1));
      gsl_matrix_set(o_ZZ,0,0,gsl_matrix_get(o_ZZ,0,0)+G_ONE);
      gsl_matrix_set(o_ZZ,0,1,gsl_matrix_get(o_ZZ,0,1)+gsl_vector_get(i_x,t-1));
      gsl_matrix_set(o_ZZ,1,1,gsl_matrix_get(o_ZZ,1,1)+gsl_vector_get(i_x,t-1)*gsl_vector_get(i_x,t-1));
    }
  gsl_matrix_set(o_ZZ,1,0,gsl_matrix_get(o_ZZ,0,1));
 
  return(0);
}


// int dllm_sim_hyperpar(double *i_prior_alpha,
//                       double *i_prior_phi,
//                       double *i_prior_tau,
//                       double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
//                       const gsl_rng *i_r,
//                       double *o_alpha,double *o_phi,double *o_tau)
// {
//   int         err,i,p=2,more;
//     double      a,b,muQmu,mubarQbarmubar,sigma;
//     double      eps0,eps1;
//     double      beta0,alpha,phi,tau;
//     gsl_vector *mubar, *XZprior;
//     gsl_matrix *Qbar, *Qchol;
// 
//     //    fprintf(stderr,"prior_tau=%lf %lf %lf\n",i_prior_tau[0],i_prior_tau[1],i_prior_tau[2]);
//     if(i_prior_alpha[2]>G_ZERO && i_prior_phi[2]>G_ZERO && i_prior_tau[2]>G_ZERO)    // parameters fixed
//       {
// 	beta0 = i_prior_alpha[0];
// 	*o_phi =i_prior_phi[0];
// 	*o_alpha = i_prior_alpha[0]/(G_ONE-i_prior_phi[0]);
// 	*o_tau = i_prior_tau[0];
// 	return(0);
//       }
// #ifdef DEBUG
//     FILE       *unit;
// #endif
// 
//     mubar = gsl_vector_alloc(p);
//     XZprior = gsl_vector_alloc(p);
//     Qbar = gsl_matrix_calloc(p,p);
//     Qchol = gsl_matrix_alloc(p,p);
// 
// #ifdef DEBUG
//     unit = fopen("XX.dat","w");
//     fprintf(unit,"%lf\n",i_XX);
//     fclose(unit);
//   
//     unit = fopen("XZ.dat","w");
//     for(i=0;i<p;i++)
//         fprintf(unit,"%lf\n",gsl_vector_get(i_XZ,i));
//     fclose(unit);
// 
//     unit = fopen("ZZ.dat","w");
//     for(i=0;i<p;i++)
//         fprintf(unit,"%lf %lf\n",gsl_matrix_get(i_ZZ,i,0),gsl_matrix_get(i_ZZ,i,1));
//     fclose(unit);
// #endif
//     //Calculate Qbar=Q+sum z_tz_t' and XZprior=Q%*%mu + sum x_tz_t
//     gsl_vector_set(XZprior,0,i_prior_alpha[1]*i_prior_alpha[0]);
//     gsl_vector_set(XZprior,1,i_prior_phi[1]*i_prior_phi[0]);
//     gsl_vector_add(XZprior,i_XZ);
//     
//     gsl_matrix_set(Qbar,0,0,i_prior_alpha[1]);
//     gsl_matrix_set(Qbar,1,1,i_prior_phi[1]);
//     gsl_matrix_add(Qbar,i_ZZ);
// 
// 
// #ifdef DEBUG
//   unit = fopen("XZprior.dat","w");
//   for(i=0;i<2;i++)
//     fprintf(unit,"%lf\n",gsl_vector_get(XZprior,i));
//   fclose(unit);
//   unit = fopen("Qbar.dat","w");
//   for(i=0;i<2;i++)
//     fprintf(unit,"%lf %lf\n",gsl_matrix_get(Qbar,i,0),gsl_matrix_get(Qbar,i,1));
//   fclose(unit);
// #endif
// 
//   //For p=2, should be made more general
//   //detQ = gsl_matrix_get(Qbar,0,0)*gsl_matrix_get(Qbar,1,1)-
//   //       gsl_matrix_get(Qbar,0,1)*gsl_matrix_get(Qbar,0,1);
//   //gsl_vector_set(mubar,0,(gsl_matrix_get(Qbar,1,1)*gsl_vector_get(XZprior,0)-
//   //			   gsl_matrix_get(Qbar,0,1)*gsl_vector_get(XZprior,1))/detQ);
//   //gsl_vector_set(mubar,1,(-gsl_matrix_get(Qbar,0,1)*gsl_vector_get(XZprior,0)+
//   //			   gsl_matrix_get(Qbar,0,0)*gsl_vector_get(XZprior,1))/detQ);
// 
//   //Calculate mubar=Qbar^{-1}XZprior
//   err = gsl_vector_memcpy(mubar,XZprior);
//   err = gsl_linalg_cholesky_decomp(Qbar);
//   gsl_linalg_cholesky_svx(Qbar,mubar);
// 
// #ifdef DEBUG
//   unit = fopen("Qchol.dat","w");
//   for(i=0;i<2;i++)
//     fprintf(unit,"%lf %lf\n",gsl_matrix_get(Qbar,i,0),gsl_matrix_get(Qbar,i,1));
//   fclose(unit);
//   unit = fopen("mubar.dat","w");
//   for(i=0;i<2;i++)
//     fprintf(unit,"%lf\n",gsl_vector_get(mubar,i));
//   fclose(unit);
// #endif
//   
//   muQmu = i_prior_alpha[0]*i_prior_alpha[0]*i_prior_alpha[1] +
//     i_prior_phi[0]*i_prior_phi[0]*i_prior_phi[1];
//   mubarQbarmubar = G_ZERO;
//   for(i=0;i<p;i++)
//       mubarQbarmubar += gsl_vector_get(XZprior,i)*gsl_vector_get(mubar,i);
// 
// #ifdef DEBUG
//   unit = fopen("muQmu.dat","w");
//   fprintf(unit,"%lf %lf\n",muQmu,mubarQbarmubar);
//   fclose(unit);
// 
//   unit = fopen("prior_tau.dat","w");
//   fprintf(unit,"%lf %lf\n",i_prior_tau[0],i_prior_tau[1]);
//   fclose(unit);
// #endif
//   
//   
//   a = i_prior_tau[0]+G_HALF*(gsl_matrix_get(i_ZZ,0,0));
//   b = i_prior_tau[1]+G_HALF*(muQmu+i_XX-mubarQbarmubar);
//   //  fprintf(stderr,"prior_tau=%lf %lf %lf, a=%lf, b=%lf\n",
//   //	  i_prior_tau[0],i_prior_tau[1],i_prior_tau[2],a,b);
//   //while loop until "legal" phi value
//   more = 1;
//   while(more)
//     {
//       if(i_prior_tau[2]>G_ZERO)    // tau fixed
// 	tau = i_prior_tau[0];
//       else
// 	tau = gsl_ran_gamma(i_r,a,G_ONE/b);
//       sigma = 1/sqrt(tau);
// #ifdef DEBUG
//       unit = fopen("abtau.dat","w");
//       fprintf(unit,"%lf %lf %lf %lf %lf",a,b,tau,i_prior_tau[0],i_prior_tau[1]);
//       fclose(unit);
// #endif
// 
//       eps0 = sigma*gsl_ran_ugaussian(i_r);
//       eps1 = sigma*gsl_ran_ugaussian(i_r);
// #ifdef DEBUG
//       unit = fopen("eps.dat","w");
//       fprintf(unit,"%lf %lf\n",eps0,eps1);
//       fclose(unit);
// #endif
// 
//       phi = gsl_vector_get(mubar,1) + eps1/gsl_matrix_get(Qbar,1,1);
//       beta0 = gsl_vector_get(mubar,0) + eps0/gsl_matrix_get(Qbar,0,0) - 
// 	eps1*gsl_matrix_get(Qbar,1,0)/(gsl_matrix_get(Qbar,0,0)*gsl_matrix_get(Qbar,1,1));
//       alpha = beta0/(G_ONE-phi);
// #ifdef DEBUG
//       unit = fopen("beta.dat","w");
//       fprintf(unit,"%lf %lf %lf\n",beta0,phi,alpha);
//       fclose(unit);
// #endif
//       if(phi > -0.99 && phi < 0.99)
// 	more = 0;
//     }
// 
//   gsl_vector_free(mubar);
//   gsl_vector_free(XZprior);
//   gsl_matrix_free(Qbar);
//   gsl_matrix_free(Qchol);
// 
// 
//   *o_alpha = alpha;
//   *o_phi = phi;
//   *o_tau = tau;
// 
//   return(0);
// }
// int dllm_sim_hyperpar2(double *i_prior_alpha,
//                       double *i_prior_phi,
//                       double *i_prior_tau,
//                       double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
//                       const gsl_rng *i_r,
// 		       double *o_alpha,double *o_phi,double *o_tau,
// 		       double *o_a,double *o_b)
// {
//   int         err,i,p=2,more;
//     double      a,b,muQmu,mubarQbarmubar,sigma;
//     double      eps0,eps1;
//     double      beta0,alpha,phi,tau;
//     gsl_vector *mubar, *XZprior;
//     gsl_matrix *Qbar, *Qchol;
// 
//     //    fprintf(stderr,"prior_tau=%lf %lf %lf\n",i_prior_tau[0],i_prior_tau[1],i_prior_tau[2]);
//     if(i_prior_alpha[2]>G_ZERO && i_prior_phi[2]>G_ZERO && i_prior_tau[2]>G_ZERO)    // parameters fixed
//       {
// 	beta0 = i_prior_alpha[0];
// 	*o_phi =i_prior_phi[0];
// 	*o_alpha = i_prior_alpha[0]/(G_ONE-i_prior_phi[0]);
// 	*o_tau = i_prior_tau[0];
// 	return(0);
//       }
// #ifdef DEBUG
//     FILE       *unit;
// #endif
// 
//     mubar = gsl_vector_alloc(p);
//     XZprior = gsl_vector_alloc(p);
//     Qbar = gsl_matrix_calloc(p,p);
//     Qchol = gsl_matrix_alloc(p,p);
// 
// #ifdef DEBUG
//     unit = fopen("XX.dat","w");
//     fprintf(unit,"%lf\n",i_XX);
//     fclose(unit);
//   
//     unit = fopen("XZ.dat","w");
//     for(i=0;i<p;i++)
//         fprintf(unit,"%lf\n",gsl_vector_get(i_XZ,i));
//     fclose(unit);
// 
//     unit = fopen("ZZ.dat","w");
//     for(i=0;i<p;i++)
//         fprintf(unit,"%lf %lf\n",gsl_matrix_get(i_ZZ,i,0),gsl_matrix_get(i_ZZ,i,1));
//     fclose(unit);
// #endif
//     //Calculate Qbar=Q+sum z_tz_t' and XZprior=Q%*%mu + sum x_tz_t
//     gsl_vector_set(XZprior,0,i_prior_alpha[1]*i_prior_alpha[0]);
//     gsl_vector_set(XZprior,1,i_prior_phi[1]*i_prior_phi[0]);
//     gsl_vector_add(XZprior,i_XZ);
//     
//     gsl_matrix_set(Qbar,0,0,i_prior_alpha[1]);
//     gsl_matrix_set(Qbar,1,1,i_prior_phi[1]);
//     gsl_matrix_add(Qbar,i_ZZ);
// 
// 
// #ifdef DEBUG
//   unit = fopen("XZprior.dat","w");
//   for(i=0;i<2;i++)
//     fprintf(unit,"%lf\n",gsl_vector_get(XZprior,i));
//   fclose(unit);
//   unit = fopen("Qbar.dat","w");
//   for(i=0;i<2;i++)
//     fprintf(unit,"%lf %lf\n",gsl_matrix_get(Qbar,i,0),gsl_matrix_get(Qbar,i,1));
//   fclose(unit);
// #endif
// 
//   //For p=2, should be made more general
//   //detQ = gsl_matrix_get(Qbar,0,0)*gsl_matrix_get(Qbar,1,1)-
//   //       gsl_matrix_get(Qbar,0,1)*gsl_matrix_get(Qbar,0,1);
//   //gsl_vector_set(mubar,0,(gsl_matrix_get(Qbar,1,1)*gsl_vector_get(XZprior,0)-
//   //			   gsl_matrix_get(Qbar,0,1)*gsl_vector_get(XZprior,1))/detQ);
//   //gsl_vector_set(mubar,1,(-gsl_matrix_get(Qbar,0,1)*gsl_vector_get(XZprior,0)+
//   //			   gsl_matrix_get(Qbar,0,0)*gsl_vector_get(XZprior,1))/detQ);
// 
//   //Calculate mubar=Qbar^{-1}XZprior
//   err = gsl_vector_memcpy(mubar,XZprior);
//   err = gsl_linalg_cholesky_decomp(Qbar);
//   gsl_linalg_cholesky_svx(Qbar,mubar);
// 
// #ifdef DEBUG
//   unit = fopen("Qchol.dat","w");
//   for(i=0;i<2;i++)
//     fprintf(unit,"%lf %lf\n",gsl_matrix_get(Qbar,i,0),gsl_matrix_get(Qbar,i,1));
//   fclose(unit);
//   unit = fopen("mubar.dat","w");
//   for(i=0;i<2;i++)
//     fprintf(unit,"%lf\n",gsl_vector_get(mubar,i));
//   fclose(unit);
// #endif
//   
//   muQmu = i_prior_alpha[0]*i_prior_alpha[0]*i_prior_alpha[1] +
//     i_prior_phi[0]*i_prior_phi[0]*i_prior_phi[1];
//   mubarQbarmubar = G_ZERO;
//   for(i=0;i<p;i++)
//       mubarQbarmubar += gsl_vector_get(XZprior,i)*gsl_vector_get(mubar,i);
// 
// #ifdef DEBUG
//   unit = fopen("muQmu.dat","w");
//   fprintf(unit,"%lf %lf\n",muQmu,mubarQbarmubar);
//   fclose(unit);
// 
//   unit = fopen("prior_tau.dat","w");
//   fprintf(unit,"%lf %lf\n",i_prior_tau[0],i_prior_tau[1]);
//   fclose(unit);
// #endif
//   
//   
//   a = i_prior_tau[0]+G_HALF*(gsl_matrix_get(i_ZZ,0,0));
//   b = i_prior_tau[1]+G_HALF*(muQmu+i_XX-mubarQbarmubar);
//   *o_a=a;
//   *o_b=b;
//   //  fprintf(stderr,"prior_tau=%lf %lf %lf, a=%lf, b=%lf\n",
//   //	  i_prior_tau[0],i_prior_tau[1],i_prior_tau[2],a,b);
//   //while loop until "legal" phi value
//   more = 1;
//   while(more)
//     {
//       if(i_prior_tau[2]>G_ZERO)    // tau fixed
// 	tau = i_prior_tau[0];
//       else
// 	tau = gsl_ran_gamma(i_r,a,1/b);
//       sigma = 1/sqrt(tau);
// #ifdef DEBUG
//       unit = fopen("abtau.dat","w");
//       fprintf(unit,"%lf %lf %lf %lf %lf",a,b,tau,i_prior_tau[0],i_prior_tau[1]);
//       fclose(unit);
// #endif
// 
//       eps0 = sigma*gsl_ran_ugaussian(i_r);
//       eps1 = sigma*gsl_ran_ugaussian(i_r);
// #ifdef DEBUG
//       unit = fopen("eps.dat","w");
//       fprintf(unit,"%lf %lf\n",eps0,eps1);
//       fclose(unit);
// #endif
// 
//       phi = gsl_vector_get(mubar,1) + eps1/gsl_matrix_get(Qbar,1,1);
//       beta0 = gsl_vector_get(mubar,0) + eps0/gsl_matrix_get(Qbar,0,0) - 
// 	eps1*gsl_matrix_get(Qbar,1,0)/(gsl_matrix_get(Qbar,0,0)*gsl_matrix_get(Qbar,1,1));
//       alpha = beta0/(G_ONE-phi);
// #ifdef DEBUG
//       unit = fopen("beta.dat","w");
//       fprintf(unit,"%lf %lf %lf\n",beta0,phi,alpha);
//       fclose(unit);
// #endif
//       //if(phi > -0.99 && phi < 0.99)
// 	more = 0;
//     }
// 
//   gsl_vector_free(mubar);
//   gsl_vector_free(XZprior);
//   gsl_matrix_free(Qbar);
//   gsl_matrix_free(Qchol);
// 
// 
//   *o_alpha = alpha;
//   *o_phi = phi;
//   *o_tau = tau;
// 
//   return(0);
// }


int dllm_sim_hyperpar000(double *i_prior_alpha,
                      double *i_prior_phi,
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau)
{
    int         err,i,p=2;
    double      a,b,muQmu,mubarQbarmubar,sigma;
    double      eps0,eps1;
    double      beta0,alpha,phi,tau;
    gsl_vector *mubar, *XZprior;
    gsl_matrix *Qbar, *Qchol;

    if(i_prior_alpha[2]>G_ZERO && i_prior_phi[2]>G_ZERO && i_prior_tau[2]>G_ZERO)    // parameters fixed
      {
	*o_alpha = i_prior_alpha[0];
	*o_phi =i_prior_phi[0];
	*o_tau = i_prior_tau[0];
	return(0);
      }
#ifdef DEBUG
    FILE       *unit;
#endif

    mubar = gsl_vector_alloc(p);
    XZprior = gsl_vector_alloc(p);
    Qbar = gsl_matrix_calloc(p,p);
    Qchol = gsl_matrix_alloc(p,p);

#ifdef DEBUG
    unit = fopen("XX.dat","w");
    fprintf(unit,"%lf\n",i_XX);
    fclose(unit);
  
    unit = fopen("XZ.dat","w");
    for(i=0;i<p;i++)
        fprintf(unit,"%lf\n",gsl_vector_get(i_XZ,i));
    fclose(unit);

    unit = fopen("ZZ.dat","w");
    for(i=0;i<p;i++)
        fprintf(unit,"%lf %lf\n",gsl_matrix_get(i_ZZ,i,0),gsl_matrix_get(i_ZZ,i,1));
    fclose(unit);
#endif
    //Calculate Qbar=Q+sum z_tz_t' and XZprior=Q%*%mu + sum x_tz_t
    gsl_vector_set(XZprior,0,i_prior_alpha[1]*i_prior_alpha[0]);
    gsl_vector_set(XZprior,1,i_prior_phi[1]*i_prior_phi[0]);
    gsl_vector_add(XZprior,i_XZ);
    
    gsl_matrix_set(Qbar,0,0,i_prior_alpha[1]);
    gsl_matrix_set(Qbar,1,1,i_prior_phi[1]);
    gsl_matrix_add(Qbar,i_ZZ);


#ifdef DEBUG
  unit = fopen("XZprior.dat","w");
  for(i=0;i<2;i++)
    fprintf(unit,"%lf\n",gsl_vector_get(XZprior,i));
  fclose(unit);
  unit = fopen("Qbar.dat","w");
  for(i=0;i<2;i++)
    fprintf(unit,"%lf %lf\n",gsl_matrix_get(Qbar,i,0),gsl_matrix_get(Qbar,i,1));
  fclose(unit);
#endif

  //For p=2, should be made more general
  //detQ = gsl_matrix_get(Qbar,0,0)*gsl_matrix_get(Qbar,1,1)-
  //       gsl_matrix_get(Qbar,0,1)*gsl_matrix_get(Qbar,0,1);
  //gsl_vector_set(mubar,0,(gsl_matrix_get(Qbar,1,1)*gsl_vector_get(XZprior,0)-
  //			   gsl_matrix_get(Qbar,0,1)*gsl_vector_get(XZprior,1))/detQ);
  //gsl_vector_set(mubar,1,(-gsl_matrix_get(Qbar,0,1)*gsl_vector_get(XZprior,0)+
  //			   gsl_matrix_get(Qbar,0,0)*gsl_vector_get(XZprior,1))/detQ);

  //Calculate mubar=Qbar^{-1}XZprior
  err = gsl_vector_memcpy(mubar,XZprior);
  err = gsl_linalg_cholesky_decomp(Qbar);
  gsl_linalg_cholesky_svx(Qbar,mubar);

#ifdef DEBUG
  unit = fopen("Qchol.dat","w");
  for(i=0;i<2;i++)
    fprintf(unit,"%lf %lf\n",gsl_matrix_get(Qbar,i,0),gsl_matrix_get(Qbar,i,1));
  fclose(unit);
  unit = fopen("mubar.dat","w");
  for(i=0;i<2;i++)
    fprintf(unit,"%lf\n",gsl_vector_get(mubar,i));
  fclose(unit);
#endif
  
  muQmu = i_prior_alpha[0]*i_prior_alpha[0]*i_prior_alpha[1] +
    i_prior_phi[0]*i_prior_phi[0]*i_prior_phi[1];
  mubarQbarmubar = G_ZERO;
  for(i=0;i<p;i++)
      mubarQbarmubar += gsl_vector_get(XZprior,i)*gsl_vector_get(mubar,i);

#ifdef DEBUG
  unit = fopen("muQmu.dat","w");
  fprintf(unit,"%lf %lf\n",muQmu,mubarQbarmubar);
  fclose(unit);

  unit = fopen("prior_tau.dat","w");
  fprintf(unit,"%lf %lf\n",i_prior_tau[0],i_prior_tau[1]);
  fclose(unit);
#endif
  
  
  a = i_prior_tau[0]+G_HALF*(gsl_matrix_get(i_ZZ,0,0));// - (double) (p-1));
  b = i_prior_tau[1]+G_HALF*(muQmu+i_XX-mubarQbarmubar);
  if(i_prior_tau[2]>G_ZERO)    // tau fixed
    tau = i_prior_tau[0];
  else
    tau = gsl_ran_gamma(i_r,a,G_ONE/b);
  sigma = 1/sqrt(tau);
  #ifdef DEBUG
  unit = fopen("abtau.dat","w");
  fprintf(unit,"%lf %lf %lf %lf %lf",a,b,tau,i_prior_tau[0],i_prior_tau[1]);
  fclose(unit);
  #endif

  eps0 = sigma*gsl_ran_ugaussian(i_r);
  eps1 = sigma*gsl_ran_ugaussian(i_r);
  #ifdef DEBUG
  unit = fopen("eps.dat","w");
  fprintf(unit,"%lf %lf\n",eps0,eps1);
  fclose(unit);
  #endif

  phi = gsl_vector_get(mubar,1) + eps1/gsl_matrix_get(Qbar,1,1);
  beta0 = gsl_vector_get(mubar,0) + eps0/gsl_matrix_get(Qbar,0,0) - 
    eps1*gsl_matrix_get(Qbar,1,0)/(gsl_matrix_get(Qbar,0,0)*gsl_matrix_get(Qbar,1,1));
  alpha = beta0/(G_ONE-phi);
  #ifdef DEBUG
  unit = fopen("beta.dat","w");
  fprintf(unit,"%lf %lf %lf\n",beta0,phi,alpha);
  fclose(unit);
  #endif

  gsl_vector_free(mubar);
  gsl_vector_free(XZprior);
  gsl_matrix_free(Qbar);
  gsl_matrix_free(Qchol);


  *o_alpha = alpha;
  *o_phi = phi;
  *o_tau = tau;

  return(0);
}

int dllm_sim_hyperpar111(double *i_prior_alpha,
                      double *i_prior_phi,  //printf("%lf %lf %lf %lf %lf",a,b,tau,i_prior_tau[0],i_prior_tau[1]);
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau)
{
    int         err,i,p=2;
    double      a,b,sigma;
    double      eps0,eps1;
    double      beta0,alpha,phi,tau;

  #ifdef DEBUG
 // printf("we are here: %s\n", "dllm_sim_hyperpar111, dllm_util.c");
  #endif
  
beta0    = i_prior_alpha[0];

alpha    = beta0/(G_ONE-i_prior_phi[0]);
*o_alpha = alpha;
*o_phi   = i_prior_phi[0];
*o_tau   = i_prior_tau[0]; 

  return(0);
}
int dllm_sim_hyperpar011(double *i_prior_alpha,
                      double *i_prior_phi,
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau)
{
    int         err,i,p=2;
    double      a,b;
    double      eps0,eps1;
    double      beta0,alpha,phi,tau;

    if(i_prior_alpha[2]>G_ZERO && i_prior_phi[2]>G_ZERO)    // parameters fixed
      {
	*o_alpha = i_prior_alpha[0];
	*o_phi =i_prior_phi[0];
      }
      
     FILE       *unit; 
      
#ifdef DEBUG
    FILE       *unit;
#endif


#ifdef DEBUG
    unit = fopen("XX.dat","w");
    fprintf(unit,"%lf\n",i_XX);
    fclose(unit);
  
    unit = fopen("XZ.dat","w");
    for(i=0;i<p;i++)
        fprintf(unit,"%lf\n",gsl_vector_get(i_XZ,i));
    fclose(unit);

    unit = fopen("ZZ.dat","w");
    for(i=0;i<p;i++)
        fprintf(unit,"%lf %lf\n",gsl_matrix_get(i_ZZ,i,0),gsl_matrix_get(i_ZZ,i,1));
    fclose(unit);
#endif
    
 
  a     = i_prior_tau[0]+G_HALF*(gsl_matrix_get(i_ZZ,0,0));   
  beta0 = i_prior_alpha[0];
  
  b     =  i_prior_tau[1] + G_HALF*(i_XX - 2*beta0*gsl_vector_get(i_XZ,0) + gsl_matrix_get(i_ZZ,0,0)*pow(beta0,2) - 
	  2*i_prior_phi[0]*(gsl_vector_get(i_XZ,1) - beta0*gsl_matrix_get(i_ZZ,0,1)) + pow(i_prior_phi[0],2)*gsl_matrix_get(i_ZZ,1,1));
  
  if(i_prior_tau[2]>G_ZERO)    // tau fixed
    tau = i_prior_tau[0];
  else
    tau = gsl_ran_gamma(i_r,a,G_ONE/b);
   
  
  #ifdef DEBUG
  unit = fopen("abtau.dat","w");
  fprintf(unit,"%lf %lf %lf %lf %lf\n",a,b,tau,i_prior_tau[0],i_prior_tau[1]);
  fclose(unit);
  #endif
  
  alpha = beta0/(G_ONE-i_prior_phi[0]);
  
  *o_tau   = tau;
  *o_alpha = alpha;
  *o_phi   =i_prior_phi[0];
  
  return(0);
}
int dllm_sim_hyperpar001(double *i_prior_alpha,
                      double *i_prior_phi,
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau)
{
    int         err,i,p=2;
    double      a,b,k1,sigma;
    double      eps0;
    double      beta0,alpha,phi,tau;


#ifdef DEBUG
    FILE       *unit;
#endif

#ifdef DEBUG
    unit = fopen("XX.dat","w");
    fprintf(unit,"%lf\n",i_XX);
    fclose(unit);
  
    unit = fopen("XZ.dat","w");
    for(i=0;i<p;i++)
        fprintf(unit,"%lf\n",gsl_vector_get(i_XZ,i));
    fclose(unit);

    unit = fopen("ZZ.dat","w");
    for(i=0;i<p;i++)
        fprintf(unit,"%lf %lf\n",gsl_matrix_get(i_ZZ,i,0),gsl_matrix_get(i_ZZ,i,1));
    fclose(unit);
#endif
  
  
  a  = i_prior_tau[0]+G_HALF*(gsl_matrix_get(i_ZZ,0,0));
  
  k1 = i_prior_alpha[1]*i_prior_alpha[0] + gsl_vector_get(i_XZ,0) - i_prior_phi[0]*gsl_matrix_get(i_ZZ,0,1);
  
  b = i_prior_tau[1] + G_HALF*(i_prior_alpha[1]*pow(i_prior_alpha[0],2) + i_XX - 2*i_prior_phi[0]*gsl_vector_get(i_XZ,1)
	  + pow(i_prior_phi[0],2)*gsl_matrix_get(i_ZZ,1,1) - pow(k1,2)/(i_prior_alpha[1] +  gsl_matrix_get(i_ZZ,0,0)));
  
  
  if(i_prior_tau[2]>G_ZERO)    // tau fixed
    tau = i_prior_tau[0];
  else
    tau = gsl_ran_gamma(i_r,a,G_ONE/b);
  sigma = 1/sqrt(tau);
  

  #ifdef DEBUG
  unit = fopen("abtau.dat","w");
  fprintf(unit,"%lf %lf %lf %lf %lf",a,b,tau,i_prior_tau[0],i_prior_tau[1]);
  fclose(unit);
  #endif

  eps0 = sigma*gsl_ran_ugaussian(i_r);

  #ifdef DEBUG
  unit = fopen("eps.dat","w");
  fprintf(unit,"%lf\n",eps0);
  fclose(unit);
  #endif

  #ifdef DEBUG
  //printf("we are here: %s\n", "dllm_sim_hyperpar001, dllm_util.c");
  #endif
 
  beta0 = k1/(i_prior_alpha[1] +  gsl_matrix_get(i_ZZ,0,0)) + eps0/sqrt(i_prior_alpha[1] +  gsl_matrix_get(i_ZZ,0,0));
  phi   = i_prior_phi[0];
  alpha = beta0/(G_ONE-phi);
 
  
  #ifdef DEBUG 
  unit = fopen("beta0.dat","w");
  fprintf(unit,"%lf %lf %lf\n",beta0,phi,alpha);
  fclose(unit);
  #endif 


  *o_alpha = alpha;
  *o_phi   = phi;
  *o_tau   = tau;

  return(0);
}
int dllm_sim_hyperpar010(double *i_prior_alpha,
                      double *i_prior_phi,
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau)
{
    int         err,i,p=2;
    double      a,b,k1,sigma;
    double      eps0,eps1;
    double      beta0,alpha,phi,tau;
    gsl_vector  *XZprior;

#ifdef DEBUG
    FILE       *unit;
#endif

#ifdef DEBUG
    unit = fopen("XX.dat","w");
    fprintf(unit,"%lf\n",i_XX);
    fclose(unit);
  
    unit = fopen("XZ.dat","w");
    for(i=0;i<p;i++)
        fprintf(unit,"%lf\n",gsl_vector_get(i_XZ,i));
    fclose(unit);

    unit = fopen("ZZ.dat","w");
    for(i=0;i<p;i++)
        fprintf(unit,"%lf %lf\n",gsl_matrix_get(i_ZZ,i,0),gsl_matrix_get(i_ZZ,i,1));
    fclose(unit);
#endif

  #ifdef DEBUG
  //printf("we are here: %s\n", "dllm_sim_hyperpar010, dllm_util.c");
  #endif
  
  beta0 = i_prior_alpha[0];  /* This notation still confising */
 
  
  a  = i_prior_tau[0]+G_HALF*(gsl_matrix_get(i_ZZ,0,0));
  
  k1 = i_prior_phi[1]*i_prior_phi[0] + gsl_vector_get(i_XZ,1) - beta0*gsl_matrix_get(i_ZZ,0,1);
  
  b = i_prior_tau[1]+G_HALF*(i_prior_phi[1]*pow(i_prior_phi[0],2) + i_XX - 2*beta0*gsl_vector_get(i_XZ,0)	  
	+ pow(beta0,2)*gsl_matrix_get(i_ZZ,0,0) - pow(k1,2)/(i_prior_phi[1] +  gsl_matrix_get(i_ZZ,1,1)));
  
  
  if(i_prior_tau[2]>G_ZERO)    // tau fixed
    tau = i_prior_tau[0];
  else
    tau = gsl_ran_gamma(i_r,a,G_ONE/b);
  sigma = 1/sqrt(tau);
  
   
  #ifdef DEBUG
  unit = fopen("abtau.dat","w");
  fprintf(unit,"%lf %lf %lf %lf %lf",a,b,tau,i_prior_tau[0],i_prior_tau[1]);
  fclose(unit);
  #endif

  eps0 = sigma*gsl_ran_ugaussian(i_r);
  phi = k1/(i_prior_phi[1] +  gsl_matrix_get(i_ZZ,1,1)) + eps0/sqrt((i_prior_phi[1] +  gsl_matrix_get(i_ZZ,1,1)));
  alpha = beta0/(G_ONE-phi);
  

  #ifdef DEBUG
  unit = fopen("eps.dat","w");
  fprintf(unit,"%lf\n",eps0);
  fclose(unit);
  #endif
  
  #ifdef DEBUG
  unit = fopen("beta.dat","w");
  fprintf(unit,"%lf %lf %lf\n",beta0,phi,alpha);
  fclose(unit);
  #endif


  *o_alpha = alpha;
  *o_phi   = phi;
  *o_tau   = tau;

  return(0);
}







