#include "dllm.h"

double gsl_ldet(gsl_matrix *A_chol)
{
  int    i;
  double ldet = G_ZERO;

  for(i=0;i<A_chol->size1;i++)
    ldet += log(gsl_matrix_get(A_chol,i,i));

  return(ldet);
}

double gsl_ldmvnorm(gsl_vector *x,gsl_vector *mu,gsl_matrix *covar_chol,double ldet)
{
  int        err,i;
  double     ldens;
  gsl_vector *res, *work;

  res = gsl_vector_alloc(x->size);
  work = gsl_vector_alloc(x->size);
  err = gsl_vector_memcpy(res,x);
  err =  gsl_vector_sub(res,mu);

  ldens = -G_HALF*ldet;

  err = gsl_linalg_cholesky_solve(covar_chol,res,work);

  for(i=0;i<x->size;i++)
    ldens -= G_HALF*gsl_vector_get(res,i)*gsl_vector_get(work,i);
  
  gsl_vector_free(res);
  gsl_vector_free(work);

  return(ldens);
}

double gsl_ldmvnorm0(gsl_vector *x,gsl_matrix *covar_chol,double ldet)
{
  int        err,i;
  double     ldens;
  gsl_vector *res, *work;

  res = gsl_vector_alloc(x->size);
  work = gsl_vector_alloc(x->size);
  err = gsl_vector_memcpy(res,x);

  ldens = -G_HALF*ldet;

  err = gsl_linalg_cholesky_solve(covar_chol,res,work);

  for(i=0;i<x->size;i++)
    ldens -= G_HALF*gsl_vector_get(res,i)*gsl_vector_get(work,i);
  
  gsl_vector_free(res);
  gsl_vector_free(work);

  return(ldens);
}

double gsl_ran_gaussian_lpdf (const double x, const double sigma)
{
  double u = x / fabs (sigma);
  double logp = -(u * u + log(2*M_PI) +2*log(sigma))/ 2;

  return logp;
}

double gsl_ran_tdist_lpdf(const double x, const double nu)
{
  double logp;

  double lg1 = gsl_sf_lngamma (nu / 2);
  double lg2 = gsl_sf_lngamma ((nu + 1) / 2);

  logp = lg2 - lg1 - (nu + 1) *log(1+x*x/nu)/ 2 - log(M_PI * nu)/2;

  return logp;
}





int print_matrix(FILE *f,const gsl_matrix *m)
{
  size_t i,j;
  int status, n = 0;
  
  for (i = 0; i < m->size1; i++) {
    for (j = 0; j < m->size2; j++) {
      if ((status = fprintf(f, "%g ", gsl_matrix_get(m, i, j))) < 0)
	return -1;
      n += status;
    }
    
    if ((status = fprintf(f, "\n")) < 0)
      return -1;
    n += status;
  }
  
  return n;
}

