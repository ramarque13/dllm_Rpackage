#include <math.h>
#include <R.h>
#include <Rdefines.h>
#include <gsl/gsl_cblas.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_sf_gamma.h>
#include "gsl_util.h"
#include "dllm_util.h"
#include "utl.h"

#define  CALLOC(n,type) (type *)calloc((size_t)(n),sizeof(type))
//#define DEBUG TRUE


#define  G_PI                3.14159265  /* ? */
#define  G_ZERO              0.00000000
#define  G_HALF              0.50000000
#define  G_ONE               1.00000000
#define  G_TWO               2.00000000
#define  MAX(A,B)  ((A) > (B) ? (A) : (B))
#define  MIN(A,B)  ((A) < (B) ? (A) : (B))


