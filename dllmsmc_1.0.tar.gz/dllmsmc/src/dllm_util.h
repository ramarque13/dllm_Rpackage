int dllm_sim_x_lin(int i_nT,double *i_y,double tau0,
		   double alpha,double phi,double tau,const gsl_rng *i_r,
		   gsl_vector *o_x);
int dllm_calc_suff(int nT,int p,gsl_vector *i_x,double *o_XX,gsl_vector *o_XZ,gsl_matrix *o_ZZ);
int dllm_sim_hyperpar(double *i_prior_alpha,
		      double *i_prior_phi,double *i_prior_tau,
		      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
		      const gsl_rng *i_r,
		      double *o_alpha,double *o_phi,double *o_tau);
int dllm_sim_hyperpar2(double *i_prior_alpha,
		      double *i_prior_phi,double *i_prior_tau,
		      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
		      const gsl_rng *i_r,
		       double *o_alpha,double *o_phi,double *o_tau,
		       double *o_a,double *o_b);
// double (*dllm_sim_hyperparXXX)(double *i_prior_alpha,
//                       double *i_prior_phi,
//                       double *i_prior_tau,
//                       double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
//                       const gsl_rng *i_r,
//                       double *o_alpha,double *o_phi,double *o_tau);
int dllm_sim_hyperpar000(double *i_prior_alpha,
                      double *i_prior_phi,
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau);
int dllm_sim_hyperpar111(double *i_prior_alpha,
                      double *i_prior_phi,
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau);
int dllm_sim_hyperpar010(double *i_prior_alpha,
                      double *i_prior_phi,
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau);
int dllm_sim_hyperpar001(double *i_prior_alpha,
                      double *i_prior_phi,
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau);
int dllm_sim_hyperpar100(double *i_prior_alpha,
                      double *i_prior_phi,
                      double *i_prior_tau,
                      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
                      const gsl_rng *i_r,
                      double *o_alpha,double *o_phi,double *o_tau);
