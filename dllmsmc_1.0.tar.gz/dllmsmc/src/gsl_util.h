double gsl_ldet(gsl_matrix *A_chol);
double gsl_ldmvnorm(gsl_vector *x,gsl_vector *mu,gsl_matrix *covar_chol,double ldet);
double gsl_ldmvnorm0(gsl_vector *x,gsl_matrix *covar_chol,double ldet);
double gsl_ran_gaussian_lpdf (const double x, const double sigma);
double gsl_ran_tdist_lpdf(const double x, const double nu);
int print_matrix(FILE *f, const gsl_matrix *m);

