

ks.dllm <- function(res.smc1,res.smc2,...)
{
D <- list()
if(!is.null(res.smc1$meanT) && !is.null(res.smc2$meanT))
      {
      n <- nrow(res.smc1$meanT)
      ind1 <- c(1:n)[!is.na(res.smc1$meanT[,1])]; ind2 <- c(1:n)[!is.na(res.smc2$meanT[,1])]
      ind = intersect(ind1, ind2)
      D$meanT <- suppressWarnings(round(sapply(ind, FUN = function(i) ks.test(res.smc1$meanT[i,],res.smc2$meanT[i,])[[1]][[1]]),4))
      names(D$meanT) <- paste("Time",ind)
      }
if(!is.null(res.smc1$meanSQ) && !is.null(res.smc2$meanSQ))
      {
      n <- nrow(res.smc1$meanSQ)
      ind1 <- c(1:n)[!is.na(res.smc1$meanSQ[,1])]; ind2 <- c(1:n)[!is.na(res.smc2$meanSQ[,1])]
      ind = intersect(ind1, ind2)
      D$meanSQ <- suppressWarnings(round(sapply(ind, FUN = function(i) ks.test(res.smc1$meanSQ[i,],res.smc2$meanSQ[i,])[[1]][[1]]),4))
      names(D$meanSQ) <- paste("Time",ind)
      }
if(!is.null(res.smc1$meanC) && !is.null(res.smc2$meanC))
      {
      n <- nrow(res.smc1$meanC)
      ind1 <- c(1:n)[!is.na(res.smc1$meanC[,1])]; ind2 <- c(1:n)[!is.na(res.smc2$meanC[,1])]
      ind = intersect(ind1, ind2)
      D$meanC <- suppressWarnings(round(sapply(ind, FUN = function(i) ks.test(res.smc1$meanC[i,],res.smc2$meanC[i,])[[1]][[1]]),4))
      names(D$meanC) <- paste("Time",ind)
      }    
if(!is.null(res.smc1$meanT2) && !is.null(res.smc2$meanT2))
      {
      n <- nrow(res.smc1$meanT2)
      ind1 <- c(1:n)[!is.na(res.smc1$meanT2[,1])]; ind2 <- c(1:n)[!is.na(res.smc2$meanT2[,1])]
      ind = intersect(ind1, ind2)
      D$meanT2 <- suppressWarnings(round(sapply(ind, FUN = function(i) ks.test(res.smc1$meanT2[i,],res.smc2$meanT2[i,])[[1]][[1]]),4))
      names(D$meanT2) <- paste("Time",ind)
      }
if(!is.null(res.smc1$meanSQ2) && !is.null(res.smc2$meanSQ2))
      {
      n <- nrow(res.smc1$meanSQ2)
      ind1 <- c(1:n)[!is.na(res.smc1$meanSQ2[,1])]; ind2 <- c(1:n)[!is.na(res.smc2$meanSQ2[,1])]
      ind = intersect(ind1, ind2)
      D$meanSQ2 <- suppressWarnings(round(sapply(ind, FUN = function(i) ks.test(res.smc1$meanSQ2[i,],res.smc2$meanSQ2[i,])[[1]][[1]]),4))
      names(D$meanSQ2) <- paste("Time",ind)
      }  
if(!is.null(res.smc1$alpha2) && !is.null(res.smc2$alpha2))
      {
      n <- nrow(res.smc1$alpha2)
      ind1 <- c(1:n)[!is.na(res.smc1$alpha2[,1])]; ind2 <- c(1:n)[!is.na(res.smc2$alpha2[,1])]
      ind = intersect(ind1, ind2)
      D$alpha2 <- suppressWarnings(round(sapply(ind, FUN = function(i) ks.test(res.smc1$alpha2[i,],res.smc2$alpha2[i,])[[1]][[1]]),4))
      names(D$alpha2) <- paste("Time",ind)
      }
if(!is.null(res.smc1$alpha) && !is.null(res.smc2$alpha))
      {
      n <- nrow(res.smc1$alpha)
      ind1 <- c(1:n)[!is.na(res.smc1$alpha[,1])]; ind2 <- c(1:n)[!is.na(res.smc2$alpha[,1])]
      ind = intersect(ind1, ind2)
      D$alpha <- suppressWarnings(round(sapply(ind, FUN = function(i) ks.test(res.smc1$alpha[i,],res.smc2$alpha[i,])[[1]][[1]]),4))
      names(D$alpha) <- paste("Time",ind)
      }
if(!is.null(res.smc1$phi) && !is.null(res.smc2$phi))
      {
      n <- nrow(res.smc1$phi)
      ind1 <- c(1:n)[!is.na(res.smc1$phi[,1])]; ind2 <- c(1:n)[!is.na(res.smc2$phi[,1])]
      ind = intersect(ind1, ind2)
      D$phi <- suppressWarnings(round(sapply(ind, FUN = function(i) ks.test(res.smc1$phi[i,],res.smc2$phi[i,])[[1]][[1]]),4))
      names(D$phi) <- paste("Time",ind)
      }
if(!is.null(res.smc1$tau) && !is.null(res.smc2$tau))
      {
      n <- nrow(res.smc1$tau)
      ind1 <- c(1:n)[!is.na(res.smc1$tau[,1])]; ind2 <- c(1:n)[!is.na(res.smc2$tau[,1])]
      ind = intersect(ind1, ind2)
      D$tau <- suppressWarnings(round(sapply(ind, FUN = function(i) ks.test(res.smc1$tau[i,],res.smc2$tau[i,])[[1]][[1]]),4))
      names(D$tau) <- paste("Time",ind)
      }
D
}

       