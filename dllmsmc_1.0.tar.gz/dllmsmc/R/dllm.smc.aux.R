dllm.smc.aux <- function(y,obsmodel="lingauss",
                     alphaprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     phiprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     tauprior=list(shape=1,rate=0.001,initial=1,fixed=FALSE),
                     tau0=0.0001,
                     N=1000,b=NULL,bugs=TRUE,start.mcmc=list(m=10,nthin=1,burnin=N),
                     seed=3245) 
{
  if(!tauprior$fixed & (alphaprior$fixed | phiprior$fixed))
    stop("1 This combination of fixed paremeters is not implemented yet")
  if(tauprior$fixed & (!alphaprior$fixed & phiprior$fixed))
    stop("2 This combination of fixed paremeters is not implemented yet")
  if(tauprior$fixed & (alphaprior$fixed & !phiprior$fixed))
    stop("3 This combination of fixed paremeters is not implemented yet")
  if(alphaprior$fixed)
    alphaprior <- c(alphaprior$initial,10000,1)
  else
    alphaprior <- c(alphaprior$mu,alphaprior$prec,0)
  if(phiprior$fixed)
    phiprior <- c(phiprior$initial,10000,1)
  else
    phiprior <- c(phiprior$mu,phiprior$prec,0)
  if(tauprior$fixed)
    tauprior <- c(tauprior$initial,10000,1)
  else
    tauprior <- c(tauprior$shape,tauprior$rate,0)
  set.seed(seed)
  if(obsmodel=="lingauss")
    dlogobsmod <- dllm.dlogmodlin
  else if(obsmodel=="svmodel")
    dlogobsmod <- dllm.dlogmodsv
  else if(obsmodel=="Poisson")
    dlogobsmod <- dllm.dlogmodpois
  else
    {
      print("Invalid observation model")
      return(NULL)
    }
   
  # particle block sampling, phi unknown 
  n <- length(y)
  if(is.null(b))
    b <- n+1    #Corresponds to no blocking
  X <- matrix(0,n,N)
  alpha <- array(NA,c(n,N))
  phi <- array(NA,c(n,N))
  tau <- array(NA,c(n,N))
  X2 <- matrix(0,n,N)
  alpha2 <- array(NA,c(n,N))
  phi2 <- array(NA,c(n,N))
  tau2 <- array(NA,c(n,N))
  meanT <- array(NA,c(n,N))
  meanSQ <- array(NA,c(n,N))
  meanC <- array(NA,c(n,N))

  m <- start.mcmc$m
  #Simulate hyperparameters and X by MCMC
  if(bugs)
   {
#  	res <- dllm.bugs(y[1:start.mcmc$m],obsmodel, alphaprior,phiprior,tauprior,N=N,
#                   burnin=start.mcmc$burnin,nthin=start.mcmc$nthin)
  	res <- dllm.mcmc(y[1:start.mcmc$m],obsmodel=obsmodel, tau0=tau0,alphaprior,phiprior,tauprior,N=N,
                   burnin=start.mcmc$burnin,nthin=start.mcmc$nthin,seed=seed)
    }
  else                
    res <- dllm.inla.sim(y[1:m],obsmodel, alphaprior,phiprior,tauprior,N=N)
  #Extract X
  X[1:m,] <- res$X
  X2[1:m,] <- res$X
  #Calculate sufficient statistics, neglecting first time point
  Suff.X <- matrix(0,6,N)
  
  for(s in 2:m)
    {
      Suff.X[1,] <- Suff.X[1,] + 1
      Suff.X[2,] <- Suff.X[2,] + X[s,]
      Suff.X[3,] <- Suff.X[3,] + X[s,]^2
      Suff.X[4,] <- Suff.X[4,] + X[s-1,]
      Suff.X[5,] <- Suff.X[5,] + X[s,]*X[s-1,]
      Suff.X[6,] <- Suff.X[6,] + X[s-1,]^2
    }
  #Extract parameter estimates
  alpha[m,] <- res$alpha
  phi[m,] <- res$phi
  tau[m,] <- res$tau
  alpha2[m,] <- res$alpha
  phi2[m,] <- res$phi
  tau2[m,] <- res$tau
  #Put global sufficient statistics to 0
  Sparticle.X <- Suff.X*0
  Sprev.X <- Suff.X*0
  Sprev.resamp.X <- Suff.X*0

  meanT[m,]  <- Suff.X[2,]/Suff.X[1,]
  meanSQ[m,] <- Suff.X[3,]/Suff.X[1,]
  meanC[m,]  <- Suff.X[5,]/Suff.X[1,]

  ind1 <- 1:N
  indM <- ind1
  for(s in 2:m)
    indM <- rbind(indM,ind1)

  #Iteration over remaining time points
  write(Suff.X[,1],ncolumns=6,file="Suff_X.txt")
  write(apply(Suff.X,1,sd),6,file="Suff_sd.txt")
  w <- rep(0,N)
  for(s in (m+1):n) 
    {
      if(s%%200==0)
        print(s)

     
      #Calculating importance distributions
      imp.dist <- dllm.calc.imp.dist(alpha[s-1,] + phi[s-1,]*(X[s-1,]-alpha[s-1,]),
                                     1/tau[s-1,],y[s],obsmodel)

      #Resampling according to auxilliary filter
      r <- w + 
        dnorm(imp.dist$mu,alpha[s-1,] + phi[s-1,]*(X[s-1,]-alpha[s-1,]),1/sqrt(tau[s-1,]),log=TRUE) +
          dlogobsmod(y[s],imp.dist$mu) - dnorm(imp.dist$mu,imp.dist$mu,sqrt(imp.dist$sig2),log=TRUE)
      r2 <- exp(r-max(r))
      r2 <- r2/sum(r2)
#      print("r2")
#      print(range(r2))
      
      #Resampling
      ind <- sample(1:N,N,replace=TRUE,prob=r2)
      X[(s-1),] <- X[(s-1),ind]
      alpha[s-1,] <- alpha[s-1,ind]
      phi[s-1,] <- phi[s-1,ind]
      tau[s-1,] <- tau[s-1,ind]
      imp.dist$mu <- imp.dist$mu[ind]
      imp.dist$sig2 <- imp.dist$sig2[ind]
      ind1 <- ind1[ind]
      indM <- rbind(indM,ind1)
      r <- r[ind]
#      if(s%%b!=0)
        {
          #Also resample sufficient statistics
          Sprev.resamp.X <- Sprev.resamp.X[,ind]
          Suff.X <- Suff.X[,ind]
        }
          
      #Simulating X[s]
      X[s,] <- rnorm(N,imp.dist$mu,sqrt(imp.dist$sig2))
        
      #Update sufficient statistics
#      if(s%%b!=0)
        {
          Suff.X[1,] <- Suff.X[1,] + 1
          Suff.X[2,] <- Suff.X[2,] + X[s,]
          Suff.X[3,] <- Suff.X[3,] + X[s,]^2
          Suff.X[4,] <- Suff.X[4,] + X[s-1,]
          Suff.X[5,] <- Suff.X[5,] + X[s,]*X[s-1,]
          Suff.X[6,] <- Suff.X[6,] + X[s-1,]^2
        }
      
      #Calculating importance weights
      w <- dlogobsmod(y[s],X[s,]) +
           dnorm(X[s,],alpha[s-1,] + phi[s-1,]*(X[s-1,]-alpha[s-1,]),1/sqrt(tau[s-1,]),log=TRUE) -
           dnorm(X[s,],imp.dist$mu,sqrt(imp.dist$sig2),log=TRUE) - r
      w2 <- exp(w-max(w))
      w2 <- w2/sum(w2)
#      print("w2")
#      print(range(w2))
      
      if(s%%b==0)
        {
          print("Blocking")
          Sparticle.X <- Sparticle.X + Sprev.X
          Sprev.X <- Suff.X
          Sprev.resamp.X <- Sprev.X
          Suff.X <- Suff.X*0
        }
     S <- Sparticle.X+Sprev.resamp.X+Suff.X
     meanT[s,] <- S[2,]/S[1,]
     meanSQ[s,] <- S[3,]/S[1,]
     meanC[s,] <- S[5,]/S[1,]

  #Simulate hyperparameters from posterior given X_{1:s-1}

     write(S[,1],file="Suff_X.txt",ncolumns=6,append=TRUE)
     write(apply(S,1,sd),6,file="Suff_sd.txt",append=TRUE)
      res <- dllm.hyperparsim(S,tauprior,alphaprior,phiprior,sample(1:10^6,1))
      alpha[s,] <- res$alpha
      phi[s,] <- res$phi
      tau[s,] <- res$tau

      ind <- sample(1:N,N,replace=TRUE,prob=w2)
      X2[s,] <- X[s,ind]
      alpha2[s,] <- alpha[s,ind]
      phi2[s,] <- phi[s,ind]
      tau2[s,] <- tau[s,ind]
      gc()
     }
  res <- list(X=X2,alpha=alpha2,phi=phi2,tau=tau2,meanT=meanT,meanSQ=meanSQ,meanC=meanC,start=m,Suff.X=Suff.X,indM=indM)
  class(res) <- "dllmsmc"
  res
}
