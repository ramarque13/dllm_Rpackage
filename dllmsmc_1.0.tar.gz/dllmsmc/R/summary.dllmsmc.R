summary.dllmsmc <- function(res.smc,prob=c(0.5,0.1,0.9))
  {
    res <- list()
    if(!is.null(res.smc$X))
      {
        res$X <- matrix(NA,nrow=nrow(res.smc$X),ncol=3)
        #res$x[,1] <- apply(res.smc$X,1,quantile,prob[1],na.rm=TRUE)
        res$X[,1] <- apply(res.smc$X,1,mean,na.rm=TRUE)
        res$X[,2] <- apply(res.smc$X,1,quantile,prob[2],na.rm=TRUE)
        res$X[,3] <- apply(res.smc$X,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$X) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$X) <- paste("Time",1:nrow(res$X))
      }
    if(!is.null(res.smc$meanT))
      {
        res$meanT <- matrix(NA,nrow=nrow(res.smc$meanT),ncol=3)
        #res$meanT[,1] <- apply(res.smc$meanT,1,quantile,prob[1],na.rm=TRUE)
        res$meanT[,1] <- apply(res.smc$meanT,1,mean,na.rm=TRUE)
        res$meanT[,2] <- apply(res.smc$meanT,1,quantile,prob[2],na.rm=TRUE)
        res$meanT[,3] <- apply(res.smc$meanT,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$meanT) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$meanT) <- paste("Time",1:nrow(res$meanT))
      }     
    if(!is.null(res.smc$meanSQ))
      {
        res$meanSQ <- matrix(NA,nrow=nrow(res.smc$meanSQ),ncol=3)
        res$meanSQ[,1] <- apply(res.smc$meanSQ,1,quantile,prob[1],na.rm=TRUE)
        res$meanSQ[,1] <- apply(res.smc$meanSQ,1,mean,na.rm=TRUE)
        res$meanSQ[,2] <- apply(res.smc$meanSQ,1,quantile,prob[2],na.rm=TRUE)
        res$meanSQ[,3] <- apply(res.smc$meanSQ,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$meanSQ) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$meanSQ) <- paste("Time",1:nrow(res$meanSQ))
      }
    if(!is.null(res.smc$meanC))
      {
        res$meanC <- matrix(NA,nrow=nrow(res.smc$meanC),ncol=3)
        #res$meanC[,1] <- apply(res.smc$meanC,1,quantile,prob[1],na.rm=TRUE)
        res$meanC[,1] <- apply(res.smc$meanC,1,mean,na.rm=TRUE)
        res$meanC[,2] <- apply(res.smc$meanC,1,quantile,prob[2],na.rm=TRUE)
        res$meanC[,3] <- apply(res.smc$meanC,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$meanC) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$meanC) <- paste("Time",1:nrow(res$meanC))
      }
    if(!is.null(res.smc$meanDiff))
      {
        res$meanDiff <- matrix(NA,nrow=nrow(res.smc$meanDiff),ncol=3)
        #res$meanDiff[,1] <- apply(res.smc$meanDiff,1,quantile,prob[1],na.rm=TRUE)
        res$meanDiff[,1] <- apply(res.smc$meanDiff,1,mean,na.rm=TRUE)
        res$meanDiff[,2] <- apply(res.smc$meanDiff,1,quantile,prob[2],na.rm=TRUE)
        res$meanDiff[,3] <- apply(res.smc$meanDiff,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$meanDiff) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$meanDiff) <- paste("Time",1:nrow(res$meanDiff))
      }
    if(!is.null(res.smc$meanT2))
      {
        res$meanT2 <- matrix(NA,nrow=nrow(res.smc$meanT2),ncol=3)
        #res$meanT2[,1] <- apply(res.smc$meanT2,1,quantile,prob[1],na.rm=TRUE)
        res$meanT2[,1] <- apply(res.smc$meanT2,1,mean,na.rm=TRUE)
        res$meanT2[,2] <- apply(res.smc$meanT2,1,quantile,prob[2],na.rm=TRUE)
        res$meanT2[,3] <- apply(res.smc$meanT2,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$meanT2) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$meanT2) <- paste("Time",1:nrow(res$meanT2))
      }
    if(!is.null(res.smc$meanSQ2))
      {
        res$meanSQ2 <- matrix(NA,nrow=nrow(res.smc$meanSQ2),ncol=3)
        #res$meanSQ2[,1] <- apply(res.smc$meanSQ2,1,quantile,prob[1],na.rm=TRUE)
        res$meanSQ2[,1] <- apply(res.smc$meanSQ2,1,mean,na.rm=TRUE)
        res$meanSQ2[,2] <- apply(res.smc$meanSQ2,1,quantile,prob[2],na.rm=TRUE)
        res$meanSQ2[,3] <- apply(res.smc$meanSQ2,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$meanSQ2) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$meanSQ2) <- paste("Time",1:nrow(res$meanSQ2))
      }
      
    if(!is.null(res.smc$alpha))
      {
        res$alpha <- matrix(NA,nrow=nrow(res.smc$alpha),ncol=3)
        #res$alpha[,1] <- apply(res.smc$alpha,1,quantile,prob[1],na.rm=TRUE)
        res$alpha[,1] <- apply(res.smc$alpha,1,mean,na.rm=TRUE)
        res$alpha[,2] <- apply(res.smc$alpha,1,quantile,prob[2],na.rm=TRUE)
        res$alpha[,3] <- apply(res.smc$alpha,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$alpha) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$alpha) <- paste("Time",1:nrow(res$alpha))
      }
    if(!is.null(res.smc$phi))
      {
        res$phi <- matrix(NA,nrow=nrow(res.smc$phi),ncol=3)
        #res$phi[,1] <- apply(res.smc$phi,1,quantile,prob[1],na.rm=TRUE)
        res$phi[,1] <- apply(res.smc$phi,1,mean,na.rm=TRUE)
        res$phi[,2] <- apply(res.smc$phi,1,quantile,prob[2],na.rm=TRUE)
        res$phi[,3] <- apply(res.smc$phi,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$phi) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$phi) <- paste("Time",1:nrow(res$phi))
      }
    if(!is.null(res.smc$tau))
      {
        res$tau <- matrix(NA,nrow=nrow(res.smc$tau),ncol=3)
        #res$tau[,1] <- apply(res.smc$tau,1,quantile,prob[1],na.rm=TRUE)
        res$tau[,1] <- apply(res.smc$tau,1,mean,na.rm=TRUE)
        res$tau[,2] <- apply(res.smc$tau,1,quantile,prob[2],na.rm=TRUE)
        res$tau[,3] <- apply(res.smc$tau,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$tau) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$tau) <- paste("Time",1:nrow(res$tau))
      }
      if(!is.null(res.smc$tau.inla))
      {
        res$tau.inla <- matrix(NA,nrow=nrow(res.smc$tau.inla),ncol=3)
        #res$tau[,1] <- apply(res.smc$tau,1,quantile,prob[1],na.rm=TRUE)
        res$tau.inla[,1] <- apply(res.smc$tau.inla,1,mean,na.rm=TRUE)
        res$tau.inla[,2] <- apply(res.smc$tau.inla,1,quantile,prob[2],na.rm=TRUE)
        res$tau.inla[,3] <- apply(res.smc$tau.inla,1,quantile,prob[3],na.rm=TRUE)
        colnames(res$tau.inla) <- c("Mean","2.5% quantile","95.5% quantile")
        rownames(res$tau.inla) <- paste("Time",1:nrow(res$tau.inla))
      }  
    class(res) <- "dllmdynsim"
    res
  }
