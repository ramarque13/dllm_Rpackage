dllm.bugs <- function(y,obsmodel="lingauss",
                     alphaprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     phiprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     tauprior=list(shape=1,rate=0.001,initial=1,fixed=FALSE),
                     tau0=0.0001,N=1000,burnin=N,nthin=10,bugs=NULL)
{
   n <- length(y);
   #Make data global
   By <<- y
   Bm <<- n

   mbugs <- dllm.make.bugs.model(obsmodel,alphaprior,phiprior,tauprior,tau0,file="dllm_bugs_model.txt")
   dat <- mbugs$dat
   paramset <- mbugs$paramset
   init <- mbugs$init
   init$x <- c(rep(0,Bm))

   #Inits
   inits <- list(phi=0,x=c(rep(0,Bm)))
   #Call bugs
   res <- rbugs(data=dat,
                inits=list(chain1=init),
                paramSet=paramset,
                model="dllm_bugs_model.txt",
                n.chains=1,n.iter=N*nthin+burnin,n.burnin=burnin,n.thin=nthin,
                #bugsWorkingDir="./workbugs/")
                bugsWorkingDir="./workbugs/",bugs=bugs)
   #Convert to coda
   res2 <-  rbugs2coda(res)[[1]]
   resu  <- list(X=t(res2[,grep("x",colnames(res2))]))
   if(!phiprior$fixed)
     resu$phi <- res2[,grep("phi",colnames(res2))]
   if(!alphaprior$fixed)
     {
       resu$beta0 <- res2[,grep("beta0",colnames(res2))]
       if(!phiprior$fixed)
         resu$alpha <- resu$beta0/(1-resu$phi)
       else
         resu$alpha <- resu$beta0/(1-phiprior$initial)
     }
   if(!tauprior$fixed)
     resu$tau <- res2[,grep("Btau",colnames(res2))]
   resu$meanT <- res2[,grep("meanT",colnames(res2))]
   resu$meanSQ <- res2[,grep("meanSQ",colnames(res2))]
   resu$meanC <- res2[,grep("meanC",colnames(res2))]
   return(resu)
}
