# Guassian
dllm.rmodlin <- function(x,sig=1){n=length(x);rnorm(n,x,sig)}
dllm.dmodlin <- function(y,x,sig=1){dnorm(y,x,sig)}
dllm.dlogmodlin <- function(y,x,sig=1){dnorm(y,x,sig,log=TRUE)}
# SV model
dllm.rmodsv <- function(x,sig=NULL){n=length(x);rnorm(n,0,exp(0.5*x))}
dllm.dmodsv <- function(y,x,sig=NULL){dnorm(y,0,exp(0.5*x))}
dllm.dlogmodsv <- function(y,x,sig=NULL){dnorm(y,0,exp(0.5*x),log=TRUE)}
# Poisson
dllm.rmodpois <- function(x,sig=1){n=length(x);rpois(n,exp(x))}
dllm.dmodpois <- function(y,x,sig=1){dpois(y,exp(x))}
dllm.dlogmodpois <- function(y,x,sig=1){dpois(y,exp(x),log=TRUE)}
