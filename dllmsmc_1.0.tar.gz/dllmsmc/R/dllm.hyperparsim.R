dllm.hyperparsim <- function(Suff.X,tauprior,alphaprior,phiprior,seed=3245) 
{
   N <- ncol(Suff.X);
   res1 <- .C("dllm_hyperpar_sim",
              N=as.integer(N),
              Suff.X=as.numeric(Suff.X),
              alphaprior=as.numeric(alphaprior),
              phiprior=as.numeric(phiprior),
              tauprior=as.numeric(tauprior),
              seed=as.integer(seed),
              alpha=as.numeric(rep(0,N)),
              phi=as.numeric(rep(0,N)),
              tau=as.numeric(rep(0,N)))
   return(list(alpha=res1$alpha,phi=res1$phi,tau=res1$tau))
 }

