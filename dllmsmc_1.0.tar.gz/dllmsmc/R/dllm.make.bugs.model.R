dllm.make.bugs.model <- function(obsmodel="lingauss",
                                 alphaprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                                 phiprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                                 tauprior=list(shape=1,rate=0.001,initial=1,fixed=FALSE),
                                 tau0=0.0001,
                                 file="dllm_bugs_model.txt")
{
   #Make bugs model
   dat <- c("By","Bm","Btau0")
   Btau0 <<- tau0
   init <- list()
   paramset <- c("x")
   write("model{",file="dllm_bugs_model.txt")
   write("mu[1] <- 0",file="dllm_bugs_model.txt",append=TRUE)
   write("x[1] ~ dnorm(mu[1],Btau0)",file="dllm_bugs_model.txt",append=TRUE)
   write("for(i in 2:Bm){",file="dllm_bugs_model.txt",append=TRUE)
   write("mu[i] <- Bbeta0+Bphi*x[i-1]",file="dllm_bugs_model.txt",append=TRUE)
   write("x[i] ~ dnorm(mu[i],Btau)",file="dllm_bugs_model.txt",append=TRUE)
   write("x2[i] <- x[i]*x[i]",file="dllm_bugs_model.txt",append=TRUE)
   write("xdx[i] <- x[i]*x[i-1]}",file="dllm_bugs_model.txt",append=TRUE)
   write("for(i in 1:Bm){",file="dllm_bugs_model.txt",append=TRUE)
   if(obsmodel=="lingauss")
     {
       write("By[i] ~ dnorm(x[i],1)",file="dllm_bugs_model.txt",append=TRUE)
     }
   else if(obsmodel=="svmodel")
     {
       write("precy[i] <- exp(-x[i])",file="dllm_bugs_model.txt",append=TRUE)
       write("By[i] ~ dnorm(0,precy[i])",file="dllm_bugs_model.txt",append=TRUE)
     }
   else if(obsmodel=="Poisson")
     {
       write("muy[i] <- exp(x[i])",file="dllm_bugs_model.txt",append=TRUE)
       write("By[i] ~ dpois(muy[i])",file="dllm_bugs_model.txt",append=TRUE)
     }
   write("}",file="dllm_bugs_model.txt",append=TRUE)
   if(!alphaprior$fixed)
     {
       paramset <- c(paramset,"Bbeta0")
       init$Bbeta0 <- 0
       write(paste("prec.beta <- ",formatC(alphaprior$prec,format="g"),"*Btau",sep=""),
             file="dllm_bugs_model.txt",append=TRUE)
       write(paste("Bbeta0 ~ dnorm(",formatC(alphaprior$mu,format="g"),",prec.beta)",sep=""),
             file="dllm_bugs_model.txt",append=TRUE)
     }
   else
     {
       Bbeta0 <<- alphaprior$initial
       dat <- c(dat,"Bbeta0")
     }
   if(!phiprior$fixed)
     {
       paramset <- c(paramset,"Bphi")
       init$Bphi <- 0
       write(paste("prec.phi <- ",formatC(phiprior$prec,format="g"),"*Btau",sep=""),
             file="dllm_bugs_model.txt",append=TRUE)
       write(paste("Bphi ~ dnorm(",formatC(phiprior$mu,format="g"),",prec.phi)C(-0.99,0.99)",sep=""),
             file="dllm_bugs_model.txt",append=TRUE)
#       write(paste("Bphi ~ dnorm(",formatC(phiprior$mu,format="g"),",",
#                   formatC(phiprior$prec,format="g"),")",sep=""),
#             file="dllm_bugs_model.txt",append=TRUE)
     }
   else
     {
       Bphi <<- phiprior$initial
       dat <- c(dat,"Bphi")
     }
   if(!tauprior$fixed)
     {
       init$Btau <- 1
       paramset <- c(paramset,"Btau")
       write(paste("Btau ~ dgamma(",formatC(tauprior$shape,format="g"),",",
                   formatC(tauprior$rate,format="g"),")",sep=""),file="dllm_bugs_model.txt",append=TRUE)
     }
   else
     {
       Btau <<- tauprior$initial
       dat <- c(dat,"Btau")
     }
   write("meanT <- mean(x[2:Bm])",file="dllm_bugs_model.txt",append=TRUE)
   write("meanSQ <- mean(x2[2:Bm])",file="dllm_bugs_model.txt",append=TRUE)
   write("meanC <- mean(xdx[2:Bm])",file="dllm_bugs_model.txt",append=TRUE)
   paramset <- c(paramset,"meanT","meanSQ","meanC")
   write("}",file="dllm_bugs_model.txt",append=TRUE)
   list(dat=dat,paramset=paramset,init=init)
}
