dllm.sim <- function(n,phi=0.95,alpha=0,sigma.x=0.5,sigma.y=1,obsmodel="lingauss",seed=NULL)
{
  set.seed(seed)
  if(obsmodel=="lingauss")
    robsmod <- dllm.rmodlin
  else if(obsmodel=="svmodel")
    robsmod <- dllm.rmodsv
  else if(obsmodel=="Poisson")
    robsmod <- dllm.rmodpois
  else
    {
      print("Invalid observation model")
      return(NULL)
    }
    set.seed(seed)
  x <- rnorm(1,alpha,sigma.x/sqrt(1-phi^2))
  for(i in 2:n)
    x[i] <- rnorm(1,alpha + phi*(x[i-1]-alpha),sigma.x)
  y <-robsmod(x,sig=sigma.y)
  return(list(x=x,y=y))
}
  
