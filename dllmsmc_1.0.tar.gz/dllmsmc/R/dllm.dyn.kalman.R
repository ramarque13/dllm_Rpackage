dllm.dyn.kalman <- function(y,alpha=0,phi=0.5,tau.x=1,tau.y=1,m=10) 
{
  #Calculates n^{-1}\sum_{t⁼1}^nE[X_t^2|Y_{1:n}] for each n by repeated calls to dllm.kalman
  sig2.x <- 1/tau.x
  n <- length(y)
  ET <- rep(NA,m-1)
  ESQ <- rep(NA,m-1)
  EC <- rep(NA,m-1)
  for(s in 1:n)
    {
      res.klm <- dllm.kalman(d$y[1:s],alpha,phi,tau.x,tau.y,smooth=TRUE)
      if(s>(m-1))
        {
          ET <- c(ET,mean(res.klm$msmo))
          ESQ <- c(ESQ,mean(res.klm$Psmo+res.klm$msmo^2))
          EC <- c(EC,mean(res.klm$msmo[-1]*res.klm$msmo[-s]+
                          phi*res.klm.prev$Phat*res.klm$Psmo[-1]/(sig2.x+phi^2*res.klm.prev$Phat)))
        }
      res.klm.prev <- res.klm
    }
  list(ET=ET,ESQ=ESQ,EC=EC)
}
