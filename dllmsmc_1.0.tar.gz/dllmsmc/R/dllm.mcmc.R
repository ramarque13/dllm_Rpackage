dllm.mcmc <- function(y,alphaprior,phiprior,tauprior,tau0,
                      N,burnin,obsmodel,nthin,seed)
{
  nT <- length(y);
  if(obsmodel=="lingauss")
    obsmod = 0
  else if(obsmodel=="Poisson")
    obsmod = 1
  else if(obsmodel=="svmodel")
     obsmod = 2
  print(tauprior)
   input <- list(nT=as.integer(nT),
              burnin=as.integer(burnin),
              N=as.integer(N),
              thin=as.integer(nthin),
              y=as.numeric(y),
              seed=as.integer(seed),
              obsmodel=as.integer(obsmod),
              tau0=as.numeric(tau0),
              alphaprior=as.numeric(alphaprior),
              phiprior=as.numeric(phiprior),
              tauprior=as.numeric(tauprior))
   save(input,file="input.RData")

   res1 <- .C("dllm_mcmc",
              nT=as.integer(nT),
              burnin=as.integer(burnin),
              N=as.integer(N),
              thin=as.integer(nthin),
              y=as.numeric(y),
              seed=as.integer(seed),
              obsmodel=as.integer(obsmod),
              tau0=as.numeric(tau0),
              alphaprior=as.numeric(alphaprior),
              phiprior=as.numeric(phiprior),
              tauprior=as.numeric(tauprior),
              x=as.numeric(rep(0.0,nT*N)),
              alpha=as.numeric(rep(0.0,N)),
              phi=as.numeric(rep(0.0,N)),
              tau=as.numeric(rep(0.0,N)))
   resu <- list()
   resu$X <- array(res1$x,c(nT,N))
   resu$alpha <- res1$alpha
   resu$phi <- res1$phi
   resu$tau <- res1$tau
   return(resu)
}
