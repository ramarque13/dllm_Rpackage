dllm.dyn.bugs <- function(y,obsmodel="lingauss",
                     alphaprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     phiprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     tauprior=list(shape=1,rate=0.0001,initial=5,fixed=FALSE),
                     tau0=0.0001,
                     thin=1,
                     N=1000,burnin=N,nthin=10,start=10,prob=c(0.5,0.1,0.9))
{
   n <- length(y);
   mbugs <- dllm.make.bugs.model(obsmodel,alphaprior,phiprior,tauprior,tau0,file="dllm_bugs_model.txt")
   dat <- mbugs$dat
   paramset <- mbugs$paramset
   init <- mbugs$init
   Mpar <- array(NA,c(n,8,3))
   path = paste(dir(),"/",sep="")
   for(s in start:n)
     {
      if(s%%thin==0)
        {
          print(s)
          By <<- y[1:s]
          Bm <<- s
          init$x <- c(rep(0,Bm))
          #print("Call Rbugs")             #Call bugs
          #print(getwd())
          #print(dir())
          res <- rbugs(data=dat,
                       inits=list(chain1=init),
                       paramSet=paramset,
                       model="dllm_bugs_model.txt",
                       n.chains=1,n.iter=N*nthin+burnin,n.burnin=burnin,n.thin=nthin
                       #,bugsWorkingDir=path)
                       #,bugsWorkingDir="./workbugs")
                       ,bugsWorkingDir="/home/reinaldo/workbugs")
          #print("Rbugs is running...")
          res2 <-  rbugs2coda(res)[[1]]
          Mpar[s,1,]<- summary(res2[,max(grep("x",colnames(res2)))],quantiles=prob)$quantiles
          if(!phiprior$fixed)
            Mpar[s,3,]<- summary(res2[,grep("phi",colnames(res2))],quantiles=prob)$quantiles
          if(!alphaprior$fixed)
            {
              beta0 <- res2[,grep("beta0",colnames(res2))]
              if(!phiprior$fixed)
                alpha <- beta0/(1-res2[,grep("phi",colnames(res2))])
              else
                 alpha <- beta0/(1-phiprior$initial)
              Mpar[s,2,]<- summary(alpha,quantiles=prob)$quantiles
            }
          if(!tauprior$fixed)
            Mpar[s,4,]<- summary(res2[,grep("Btau",colnames(res2))],quantiles=prob)$quantiles
          Mpar[s,5,]<- summary(res2[,grep("meanT",colnames(res2))],quantiles=prob)$quantiles
          Mpar[s,6,]<- summary(res2[,grep("meanSQ",colnames(res2))],quantiles=prob)$quantiles
          Mpar[s,7,]<- summary(res2[,grep("meanC",colnames(res2))],quantiles=prob)$quantiles
        }
     }
   res <- list(x=Mpar[,1,],alpha=Mpar[,2,],phi=Mpar[,3,],tau=Mpar[,4,],
               meanT=Mpar[,5,],meanSQ=Mpar[,6,],meanC=Mpar[,7,],res.bugs=res2)
   class(res) <- "dllmdynsim"
   res
}
