dllm.inla.sim <- function(y,obsmodel="lingauss",N=1000,
                     alphaprior=list(mu=0,prec=0.00001,initial=0,fixed=FALSE),
                     rhoprior=list(mu=0,prec=0.0001,initial=5,fixed=FALSE),
                     mtauprior=list(shape=1,rate=0.0001,initial=5,fixed=FALSE),numit=1)
{
   n <- length(y);

   fam <- "gaussian"
   contr.fam <- list(hyper = list(prec = list(initial=0,fixed=1)))
   if(obsmodel=="svmodel")
     {
       fam <- "stochvol"
       contr.fam <- list()
     }
   if(obsmodel=="Poisson")
     {
       fam <- "poisson"
       contr.fam <- list()
     }
   Mpar <- array(NA,c(n,5,3))
   d.inla <- list(y=y,time=1:n)
   #Robust version of inla, calling several times with changing priors
   meanT <- inla.make.lincomb(time=rep(1/n,n))
   names(meanT) <- "meanT"
   res.inla <- inla(y~1+f(time,model="ar1",
                          hyper=list(theta1=list(param=c(mtauprior$shape,1),initial=mtauprior$initial),
                                   theta2=list(param=c(rhoprior$mu,1),initial=rhoprior$initial))),
                           control.fixed = list(mean.intercept=alphaprior$mu,prec.intercept = alphaprior$prec),
                           family=fam,data=d.inla,control.family=contr.fam)
   for(j in 1:numit)
    {
      init.mtau <- log(res.inla$summary.hyperpar[1,6])
      init.rho <- log(1.1+res.inla$summary.hyperpar[2,6])-log(1.1-res.inla$summary.hyperpar[2,6])
      print(c(j,init.mtau,init.rho,res.inla$summary.hyperpar[2,6]))
      res.inla <- inla(y~1+f(time,model="ar1",hyper=list(
             theta1=list(param=c(mtauprior$shape,mtauprior$rate^(j/numit)),initial=init.mtau),
             theta2=list(param=c(rhoprior$mu,rhoprior$prec^(j/numit)),initial=init.rho))),
             control.fixed = list(mean.intercept=alphaprior$mu,prec.intercept = alphaprior$prec),
             family=fam,data=d.inla,control.family=contr.fam)
      }
     res.inla <- inla(y~1+f(time,model="ar1",hyper=list(
             theta1=list(param=c(mtauprior$shape,mtauprior$rate^(j/numit)),initial=init.mtau),
             theta2=list(param=c(rhoprior$mu,rhoprior$prec^(j/numit)),initial=init.rho))),
             control.fixed = list(mean.intercept=alphaprior$mu,prec.intercept = alphaprior$prec),
                           family=fam,data=d.inla,control.family=contr.fam,lincomb=meanT,
                           control.inla=list(strategy="laplace"),
                           control.compute=list(config=TRUE))
     res.sim <- inla.posterior.sample(N,res.inla)
   res <- list(alpha=rep(NA,N),phi=rep(NA,N),tau=rep(NA,N),X=matrix(NA,nrow=n,ncol=N))
   for(i in 1:N)
     {
     	res$tau[i] <- res.sim[[i]]$hyperpar[1]
     	res$phi[i] <- res.sim[[i]]$hyperpar[2]
     	res$X[,i] <- res.sim[[i]]$latent[n+1:n]
     	res$alpha[i] <- res.sim[[i]]$latent[2*n+1]
     }  
#   list(res=res,res.inla=res.inla)
    res
}
