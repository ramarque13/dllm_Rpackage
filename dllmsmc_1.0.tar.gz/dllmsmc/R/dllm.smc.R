dllm.smc <- function(y,obsmodel="lingauss",
                     alphaprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     phiprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     tauprior=list(shape=1,rate=0.001,initial=1,fixed=FALSE),
                     tau0=0.0001,N=1000,b=NULL,b.initial=NULL,k=NULL,initial.method="MCMC",start.mcmc=list(m=10,nthin=1,burnin=N),
                     par.resample=list(method="stratified",nonuniformity="none",threshold = 0.5,engine="C",
                     log=FALSE,normalized=TRUE),seed=3245) 
{
 # if(!tauprior$fixed & (alphaprior$fixed | phiprior$fixed))
 #    stop("1 This combination of fixed paremeters is not implemented yet")
 # if(tauprior$fixed & (!alphaprior$fixed & phiprior$fixed))
 #   stop("2 This combination of fixed paremeters is not implemented yet")
 # if(tauprior$fixed & (alphaprior$fixed & !phiprior$fixed))
 #   stop("3 This combination of fixed paremeters is not implemented yet")

 
 #   if(alphaprior$fixed)
#     alphaprior <- c(alphaprior$initial,10000,1)
#   else
#     alphaprior <- c(alphaprior$mu,alphaprior$prec,0)
#  if(phiprior$fixed)
#     phiprior <- c(phiprior$initial,10000,1)
#   else
#     phiprior <- c(phiprior$mu,phiprior$prec,0)
#   if(tauprior$fixed)
#     tauprior <- c(tauprior$initial,10000,1)
#   else
#     tauprior <- c(tauprior$shape,tauprior$rate,0)


  set.seed(seed)
  if(obsmodel=="lingauss")
    dlogobsmod <- dllm.dlogmodlin
  else if(obsmodel=="svmodel")
    dlogobsmod <- dllm.dlogmodsv
  else if(obsmodel=="Poisson")
    dlogobsmod <- dllm.dlogmodpois
  else
    {
      print("Invalid observation model")
      return(NULL)
    }
   
  require("INLA"); require("smcUtils")
  
  # particle block sampling, phi unknown 
  n <- length(y)
  if(is.null(b))
    b <- n+1    #Corresponds to no blocking
  if(is.null(b.initial))
    b.initial <- 1
  X <- matrix(,n,N)
  alpha <- array(NA,c(n,N));  phi <- array(NA,c(n,N))
  tau <- array(NA,c(n,N));    tau.inla <- array(NA,c(n,N))
  meanT <- array(NA,c(n,N))
  meanSQ <- array(NA,c(n,N))
  meanC <- array(NA,c(n,N))
  meanDiff <- array(NA,c(n,N)); meanT2 <- array(NA,c(n,N)); meanSQ2 <- array(NA,c(n,N))
  m <- start.mcmc$m; ESS=NULL
  #Simulate hyperparameters and X by MCMC
  if(initial.method!="INLA")
   {  
    if(initial.method=="bugs")
      {
    print("Running R-bugs")
    res <- dllm.bugs(y[1:start.mcmc$m],obsmodel, alphaprior,phiprior,tauprior,N=N,
             burnin=start.mcmc$burnin,nthin=start.mcmc$nthin)
   alphaprior <- c(alphaprior$mu,alphaprior$prec,0); phiprior <- c(phiprior$mu,phiprior$prec,0); 
   tauprior <- c(tauprior$shape,tauprior$rate,0)
   
      }
  else
   {
  if(alphaprior$fixed)
    alphaprior <- c(alphaprior$initial,10000,1)
  else
    alphaprior <- c(alphaprior$mu,alphaprior$prec,0)
  if(phiprior$fixed)
    phiprior <- c(phiprior$initial,10000,1)
  else
    phiprior <- c(phiprior$mu,phiprior$prec,0)
  if(tauprior$fixed)
    tauprior <- c(tauprior$initial,10000,1)
  else
    tauprior <- c(tauprior$shape,tauprior$rate,0)
  
    print("Starting with MCMC steps")
    res <- dllm.mcmc(y[1:start.mcmc$m],tau0=tau0, alphaprior=alphaprior,phiprior=phiprior,tauprior=tauprior,
                  N=N,burnin=start.mcmc$burnin,nthin=start.mcmc$nthin,seed=seed,obsmodel=obsmodel)
       }            
    }
  else                
      {
    print("Starting with R-Inla steps")
    res <- dllm.inla.sim(y[1:m],obsmodel=obsmodel,alphaprior=alphaprior,rhoprior=phiprior,mtauprior=tauprior,N=N)
      }
         
  #Extract X
  X[1:m,] = res$X
  #Calculate sufficient statistics, neglecting first time point
  Suff.X <- matrix(0,6,N)
  for(s in 2:m)
    {
      Suff.X[1,] <- Suff.X[1,] + 1
      Suff.X[2,] <- Suff.X[2,] + X[s,]
      Suff.X[3,] <- Suff.X[3,] + X[s,]^2
      Suff.X[4,] <- Suff.X[4,] + X[s-1,]
      Suff.X[5,] <- Suff.X[5,] + X[s,]*X[s-1,]
      Suff.X[6,] <- Suff.X[6,] + X[s-1,]^2
    }
  #Extract parameter estimates
 
  alpha[m,] <- res$alpha[1:N]; phi[m,] <- res$phi[1:N];  tau[m,] <- res$tau[1:N]
  
  #tau.inla[m,] <- tau[m,]*(1-phi[m,]^2)
  phi.inla <- ifelse(phi[m,]>1,1,-1)
  tau.inla[s,] <-tau[m,]*(1-phi.inla^2)
  
  #Put global sufficient statistics to 0
  Sparticle.X <- Suff.X*0
  Sprev.X <- Suff.X*0
  Sprev.resamp.X <- Suff.X*0

  meanT[m,]    <- Suff.X[2,]/Suff.X[1,]
  meanSQ[m,]   <- Suff.X[3,]/Suff.X[1,]
  meanC[m,]    <- Suff.X[5,]/Suff.X[1,]
  meanDiff[m,] <- Suff.X[5,]/Suff.X[6,]
  meanT2[m,]   <- Suff.X[4,]/Suff.X[1,]
  meanSQ2[m,]  <- Suff.X[6,]/Suff.X[1,]
  
  ind1 <- 1:N
  indM <- ind1
  for(s in 2:m)
    indM <- rbind(indM,ind1)
  
  for(s in (m+1):n) 
    {
     if(s%%200==0)
        print(s)
        
      #Calculating importance distributions
      imp.dist <- dllm.calc.imp.dist(alpha[s-1,] + phi[s-1,]*(X[s-1,]-alpha[s-1,]),1/tau[s-1,],y[s],obsmodel)
           
      #Simulating X[s]
      X[s,] <- rnorm(N,imp.dist$mu,sqrt(imp.dist$sig2))
        
      #Update sufficient statistics
  #    if(s%%b!=0)
        {
          Suff.X[1,] <- Suff.X[1,] + 1
          Suff.X[2,] <- Suff.X[2,] + X[s,]
          Suff.X[3,] <- Suff.X[3,] + X[s,]^2
          Suff.X[4,] <- Suff.X[4,] + X[s-1,]
          Suff.X[5,] <- Suff.X[5,] + X[s,]*X[s-1,]
          Suff.X[6,] <- Suff.X[6,] + X[s-1,]^2
        }
      
      #Calculating importance weights
      w <- dlogobsmod(y[s],X[s,]) + dnorm(X[s,],alpha[s-1,] + phi[s-1,]*(X[s-1,]-alpha[s-1,]),1/sqrt(tau[s-1,]),log=TRUE) -
           dnorm(X[s,],imp.dist$mu,sqrt(imp.dist$sig2),log=TRUE)
      w <- exp(w-max(w))
      w <- w/sum(w)
      
      ESS[s] = 1/sum(w^2)
      #Resampling
      #ind <- sample(1:N,N,replace=TRUE,prob=w)
            
      ind <-resample(w,method=par.resample$methd,nonuniformity=par.resample$nonuniformity,threshold=par.resample$threshold,
      engine=par.resample$engine,log=par.resample$log,normalized=par.resample$normalized)$indices
      
      X[s,] <- X[s,ind]
      ind1 <- ind1[ind]
      indM <- rbind(indM,ind1)
#      if(s%%b!=0)
        {
          #Also resample sufficient statistics
          Sprev.resamp.X <- Sprev.resamp.X[,ind]
          Suff.X <- Suff.X[,ind]
        }
      
      if(s%%b==0 && s > b.initial)
        {
          print("Blocking");  print(s)
          Sparticle.X <- Sparticle.X + Sprev.X
          Sprev.X <- Suff.X
          Sprev.resamp.X <- Sprev.X
          Suff.X <- Suff.X*0
        }

      if(!is.null(k))
	S <- Sparticle.X+Sprev.resamp.X+Suff.X
      else
	S <- Sparticle.X+Sprev.X+Suff.X
            
      meanT[s,]    <- S[2,]/S[1,]
      meanSQ[s,]   <- S[3,]/S[1,]
      meanC[s,]    <- S[5,]/S[1,]
      meanDiff[s,] <- S[5,]/S[6,]
      meanT2[s,]   <- S[4,]/S[1,] 
      meanSQ2[s,]  <- S[6,]/S[1,]
   
   #Simulate hyperparameters from posterior given X_{1:s-1}
         
      res <- dllm.hyperparsim(S,tauprior,alphaprior,phiprior,sample(1:10^6,1))
      alpha[s,] <- res$alpha
      phi[s,] <- res$phi
      tau[s,] <- res$tau
      phi.inla <- ifelse(phi[s,]>1,1,-1)
      tau.inla[s,] <-tau[s,]*(1-phi.inla^2)
      
      gc()
     }
  res <- list(X=X,alpha=alpha,phi=phi,tau=tau,tau.inla=tau.inla,meanT=meanT,meanSQ=meanSQ,meanC=meanC,meanDiff=meanDiff,meanT2=meanT2,meanSQ2=meanSQ2,start=m,Suff.X=Suff.X,ESS=ESS)
  class(res) <- "dllmsmc"
  res
}
