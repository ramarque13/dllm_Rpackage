dllm.kalman <- function(y,alpha=0,phi=0.5,tau.x=1,tau.y=1,smooth=TRUE) 
{
  sigx2 <- 1/tau.x
  sigy2 <- 1/tau.y
  #Assumes obs is N(0,sigy2)
  P <- sigx2/(1-phi^2)
  m <- alpha
  n <- length(y)
  mhat <- rep(NA,n)
  Phat <- rep(NA,n)
  #Kalman filter
  for(s in 1:n)
    {
      P1 <- phi^2*P + sigx2
      S <- P1 + sigy2
      K <- P1/S
      P <- (1-K)*P1
      m1 <- alpha+phi*(m-alpha)
      m <- m1 + K*(y[s]-m1)
      mhat[s] <- m
      Phat[s] <- P
    }
  res <- list(mhat=mhat,Phat=Phat)
  if(smooth)
    {
      msmo <- rep(NA,n)
      Psmo <- rep(NA,n)
      msmo[n] <- mhat[n]
      Psmo[n] <- Phat[n]
      for(s in (n-1):1)
        {
          P1 <- phi^2*Phat[s] + sigx2
          m1 <- alpha+phi*(mhat[s]-alpha)
          A <- Phat[s]*phi/P1
          msmo[s] <- mhat[s] + A*(msmo[s+1]-m1)
          Psmo[s] <- Phat[s] + A*(Psmo[s+1]-P1)*A
        }
      res$msmo <- msmo
      res$Psmo <- Psmo
    }
  res
}
