dllm.dyn.mcmc <- function(y,obsmodel="lingauss",
                          alphaprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                          phiprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                          tauprior=list(shape=1,rate=0.001,initial=1,fixed=FALSE),
                          tau0=0.0001,
                          thin=1,
                          N=1000,burnin=N,nthin=10,start=10,seed=3245)
{
#   if(!tauprior$fixed & (alphaprior$fixed | phiprior$fixed))
#     stop("1 This combination of fixed paremeters is not implemented yet")
#   if(tauprior$fixed & (!alphaprior$fixed & phiprior$fixed))
#     stop("2 This combination of fixed paremeters is not implemented yet")
#   if(tauprior$fixed & (alphaprior$fixed & !phiprior$fixed))
#     stop("3 This combination of fixed paremeters is not implemented yet")
  if(alphaprior$fixed)
    alphaprior <- c(alphaprior$initial,10000,1)
  else
    alphaprior <- c(alphaprior$mu,alphaprior$prec,0)
  if(phiprior$fixed)
    phiprior <- c(phiprior$initial,10000,1)
  else
    phiprior <- c(phiprior$mu,phiprior$prec,0)
  if(tauprior$fixed)
    tauprior <- c(tauprior$initial,10000,1)
  else
    tauprior <- c(tauprior$shape,tauprior$rate,0)
  set.seed(seed)
  nT <- length(y);

  X <- matrix(NA,nrow=nT,ncol=N)
  meanT <- matrix(NA,nrow=nT,ncol=N)
  meanSQ <- matrix(NA,nrow=nT,ncol=N)
  meanC <- matrix(NA,nrow=nT,ncol=N)
  meanDiff <- matrix(NA,nrow=nT,ncol=N)
  meanT2 <- matrix(NA,nrow=nT,ncol=N)
  meanSQ2 <- matrix(NA,nrow=nT,ncol=N)
  alpha <- matrix(NA,nrow=nT,ncol=N)
  phi <- matrix(NA,nrow=nT,ncol=N)
  tau <- matrix(NA,nrow=nT,ncol=N)
  tau.inla <- matrix(NA,nrow=nT,ncol=N)
   for(s in start:nT)
     {
      if(s%%thin==0)
        {
          print(s)
                                        #Call dllm.mcmc.C
          #seed <- sample(1:10^6,1)
          res <- dllm.mcmc(y=y[1:s],obsmodel=obsmodel,tau0=tau0,
                             alphaprior=alphaprior,phiprior=phiprior,tauprior=tauprior,
                             N=N,burnin=burnin,nthin=nthin,seed=seed)
          alpha[s,] <- res$alpha
          phi[s,] <- res$phi
          tau[s,] <- res$tau
          tau.inla[s,] <- tau[s,]*(1-phi[s,]^2)
                 
          X[s,] <- res$X[s,]
         
          meanT[s,]     <- colMeans(res$X[-1,])
          meanSQ[s,]    <- colMeans(res$X[-1,]^2)
          meanC[s,]     <- colMeans(res$X[-1,]*res$X[-s,])
          meanDiff[s,]  <- colSums(res$X[-1,]*res$X[-s,])/colSums(res$X[-s,]^2)
          meanT2[s,]    <- colMeans(res$X[-s,])
          meanSQ2[s,]   <- colMeans(res$X[-s,]^2) 
       
        }
     }
    
    
     
   res <- list(alpha=alpha,phi=phi,tau=tau,tau.inla=tau.inla,X=X,meanT=meanT,meanSQ=meanSQ,meanC=meanC,meanDiff=meanDiff,meanSQ2=meanSQ2,meanT2=meanT2)
   class(res) <- c("dllmmcmc","dllmsmc")
   res
}
