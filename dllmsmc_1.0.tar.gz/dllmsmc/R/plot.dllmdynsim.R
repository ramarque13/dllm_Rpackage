plot.dllmdynsim <- function(res.dynsim,res.dynsim2=NULL,res.dynsim3=NULL,res.dynsim4=NULL,X=NULL,alpha=NULL,phi=NULL,tau=NULL,
                            X.lim=NULL,meanT.lim=NULL,meanSQ.lim=NULL,meanC.lim=NULL,meanDiff.lim=NULL,
                            meanT2.lim=NULL,meanSQ2.lim=NULL,
                            alpha.lim=NULL,phi.lim=NULL,tau.lim=NULL,main="",window=NULL,CI=TRUE,tau.inla=FALSE,
                            display.plot=rep(1,9),col.plots=TRUE,...)
  {
  if(is.null(res.dynsim$X)) display.plot[1]=0;     if(is.null(res.dynsim$meanT)) display.plot[2]=0;  if(is.null(res.dynsim$meanSQ)) display.plot[3]=0;  
  if(is.null(res.dynsim$meanC)) display.plot[4]=0; if(is.null(res.dynsim$meanT2)) display.plot[5]=0; if(is.null(res.dynsim$meanSQ2)) display.plot[6]=0;  
  if(is.null(res.dynsim$alpha)) display.plot[7]=0; if(is.null(res.dynsim$phi)) display.plot[8]=0;    if(is.null(res.dynsim$tau)) display.plot[9]=0;  

  par.save <- par()

  
  if(!col.plots)
    par.col = rep("black",4)
  else
     par.col = c("lightslateblue","gray","black","navyblue")
 
  switch(sum(display.plot),par(mfrow=c(1,1)),par(mfrow=c(2,1)),par(mfrow=c(3,1)),par(mfrow=c(2,2)),
        par(mfrow=c(3,2)),par(mfrow=c(3,2)),par(mfrow=c(3,3)),par(mfrow=c(3,3)),par(mfrow=c(3,3)),par(mfrow=c(4,3)),
        par(mfrow=c(2,5)),par(mfrow=c(5,2)),par(mfrow=c(4,4)))
    meanT <- NULL;meanSQ=NULL;meanC=NULL; meanDiff=NULL; meanT2 <- NULL; meanSQ2=NULL;
       
    if(display.plot[1]==1)
      {
        n <- nrow(res.dynsim$X)
        if(is.null(window))
	  ind <- c(1:n)[!is.na(res.dynsim$X[,1])]
	else
	  ind <- window
	if(is.null(res.dynsim3$X))
	 {
        matplot(cbind(ind,ind,ind),res.dynsim$X[ind,],type="l",
                lty=c(1,2,2),col=par.col[1],lwd=1.5,xlab="Time",ylab="X",ylim=X.lim,main=main)
        if(!is.null(X))
          {
            lines(1:n,X,col=1)
            meanT <- cumsum(X)/c(1:n)
          }
        if(!is.null(res.dynsim2$X))
          {
             if(is.null(window))
	      ind2 <- c(1:n)[!is.na(res.dynsim2$X[,1])]
            else
	      ind2 <- window
            matlines(cbind(ind2,ind2,ind2),res.dynsim2$X[ind2,],lwd=1.5,type="l",lty=c(1,2,2),col=par.col[2])
          }
         }
       else
	  {
	  if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$X[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$X[,1])]}
	  else{ind2 <- ind3 <- window}
	    if(!CI){
	  matplot(ind,res.dynsim$X[ind,1],type="l",lwd=1.5,lty=1,col=par.col[1],xlab="Time",ylab="X",ylim=X.lim,main=main)
	  matlines(ind2,res.dynsim2$X[ind2,1],type="l",lwd=1.5,lty=2,col=par.col[2])
	  matlines(ind3,res.dynsim3$X[ind3,1],type="l",lwd=1.5,lty=3,col=par.col[3])
	    if(!is.null(res.dynsim4$X)) matlines(ind2,res.dynsim4$X[ind2,1],lwd=1.5,type="l",lty=4,col=par.col[4]) 
	    }
	  else{
	  matplot(cbind(ind,ind,ind),res.dynsim$X[ind,],type="l",lty=1,col=par.col[1],lwd=1.5,xlab="Time",ylab="X",ylim=X.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$X[ind2,],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$X[ind3,],type="l",lty=3,lwd=1.5,col=par.col[3])
	    if(!is.null(res.dynsim4$X)) matlines(ind2,res.dynsim4$X[ind2,],type="l",lty=4,lwd=1.5,col=par.col[4]) 
	    }	  
	  }
      }
     
     if(display.plot[2]==1)
      {
        n <- nrow(res.dynsim$meanT)
	 if(is.null(window))
	  ind <- c(1:n)[!is.na(res.dynsim$meanT[,1])]
	 else
	  ind <- window   
      if(is.null(res.dynsim3$meanT))
	 {
        matplot(cbind(ind,ind,ind),res.dynsim$meanT[ind,],
                type="l",lty=c(1,2,2),col=par.col[1],lwd=1.5,xlab="Time",ylab="mean X",ylim=meanT.lim,main=main)
        if(!is.null(meanT))
          lines(1:n,meanT,col=1)
        if(!is.null(res.dynsim2$meanT))
          {
	  if(is.null(window))
	    ind2 <- c(1:n)[!is.na(res.dynsim2$meanT[,1])]
	  else
	    ind2 <- window
          matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanT[ind2,],type="l",lwd=1.5,lty=c(1,2,2),col=par.col[2])
          }
        }   
      else
	  {
	  if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$meanT[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$meanT[,1])]}
	  else{ind2 <- ind3 <- window}
	  if(!CI){
	  matplot(ind,res.dynsim$meanT[ind,1],type="l",lty=1,col=par.col[1],lwd=1.5,xlab="Time",ylab="mean X",ylim=meanT.lim,main=main)
	  matlines(ind2,res.dynsim2$meanT[ind2,1],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(ind3,res.dynsim3$meanT[ind3,1],type="l",lty=3,lwd=1.5,col=par.col[3])
	    if(!is.null(res.dynsim4$meanT)) matlines(ind2,res.dynsim4$meanT[ind2,1],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }
	  else{
	  matplot(cbind(ind,ind,ind),res.dynsim$meanT[ind,],type="l",lty=1,lwd=1.5,col=par.col[1],xlab="Time",ylab="mean X",ylim=meanT.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanT[ind2,],type="l",lwd=1.5,lty=2,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$meanT[ind3,],type="l",lty=3,lwd=1.5,col=par.col[3])	  
	    if(!is.null(res.dynsim4$meanT)) matlines(ind2,res.dynsim4$meanT[ind2,],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }	  
	  }
      }
   
     if(display.plot[3]==1)
      {
        n <- nrow(res.dynsim$meanSQ)
	 if(is.null(window))
	  ind <- c(1:n)[!is.na(res.dynsim$meanSQ[,1])]
	 else
	  ind <- window   
      if(is.null(res.dynsim3$meanSQ))
	 {
        matplot(cbind(ind,ind,ind),res.dynsim$meanSQ[ind,],
                type="l",lty=c(1,2,2),col=par.col[1],lwd=1.5,xlab="Time",ylab="mean SQ",ylim=meanSQ.lim,main=main)
        if(!is.null(meanSQ))
          lines(1:n,meanSQ,col=1)
        if(!is.null(res.dynsim2$meanSQ))
          {
	  if(is.null(window))
	    ind2 <- c(1:n)[!is.na(res.dynsim2$meanSQ[,1])]
	  else
	    ind2 <- window
          matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanSQ[ind2,],type="l",lwd=1.5,lty=c(1,2,2),col=par.col[2])
          }
        }   
      else
	  {
	   if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$meanSQ[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$meanSQ[,1])]}
	  else{ind2 <- ind3 <- window}
	  if(!CI){
	  matplot(ind,res.dynsim$meanSQ[ind,1],type="l",lty=1,col=par.col[1],xlab="Time",lwd=1.5,ylab="mean SQ",ylim=meanSQ.lim,main=main)
	  matlines(ind2,res.dynsim2$meanSQ[ind2,1],type="l",lwd=1.5,lty=2,col=par.col[2])
	  matlines(ind3,res.dynsim3$meanSQ[ind3,1],type="l",lty=3,lwd=1.5,col=par.col[3])
	  if(!is.null(res.dynsim4$meanSQ)) matlines(ind2,res.dynsim4$meanSQ[ind2,1],lwd=1.5,type="l",lty=4,col=par.col[4]) 
	    }
	  else{
	  matplot(cbind(ind,ind,ind),res.dynsim$meanSQ[ind,],type="l",lty=1,col=par.col[1],lwd=1.5,xlab="Time",ylab="mean SQ",ylim=meanSQ.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanSQ[ind2,],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$meanSQ[ind3,],type="l",lty=3,lwd=1.5,col=par.col[3])	  
	    if(!is.null(res.dynsim4$meanSQ)) matlines(ind2,res.dynsim4$meanSQ[ind2,],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }	  
	  }
      }
 
  if(display.plot[4]==1)
      {
        n <- nrow(res.dynsim$meanC)
	 if(is.null(window))
	  ind <- c(1:n)[!is.na(res.dynsim$meanC[,1])]
	 else
	  ind <- window   
      if(is.null(res.dynsim3$meanC))
	 {
        matplot(cbind(ind,ind,ind),res.dynsim$meanC[ind,],
                type="l",lty=c(1,2,2),col=par.col[1],lwd=1.5,xlab="Time",ylab="mean C",lwd=1.5,ylim=meanC.lim,main=main)
        if(!is.null(meanC))
          lines(1:n,meanC,col=1)
        if(!is.null(res.dynsim2$meanC))
          {
	  if(is.null(window))
	    ind2 <- c(1:n)[!is.na(res.dynsim2$meanC[,1])]
	  else
	    ind2 <- window
          matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanC[ind2,],type="l",lty=c(1,2,2),lwd=1.5,col=par.col[2])
          }
        }   
      else
	  {
	  if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$meanC[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$meanC[,1])]}
	  else{ind2 <- ind3 <- window}
	    if(!CI){
	  matplot(ind,res.dynsim$meanC[ind,1],type="l",lty=1,lwd=1.5,col=par.col[1],xlab="Time",ylab="mean C",ylim=meanC.lim,main=main)
	  matlines(ind2,res.dynsim2$meanC[ind2,1],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(ind3,res.dynsim3$meanC[ind3,1],type="l",lty=3,lwd=1.5,col=par.col[3])
	  if(!is.null(res.dynsim4$meanC)) matlines(ind2,res.dynsim4$meanC[ind2,1],type="l",lty=4,lwd=1.5,col=par.col[4]) 
	    }
	  else{
	  matplot(cbind(ind,ind,ind),res.dynsim$meanC[ind,],type="l",lty=1,col=par.col[1],lwd=1.5,xlab="Time",ylab="mean C",ylim=meanC.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanC[ind2,],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$meanC[ind3,],type="l",lty=3,lwd=1.5,col=par.col[3])	  
	    if(!is.null(res.dynsim4$meanC)) matlines(ind2,res.dynsim4$meanC[ind2,],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }	  
	  }
      }
      
      if(display.plot[5]==1)
      {
        n <- nrow(res.dynsim$meanSQ2)
	 if(is.null(window))
	  ind <- c(1:n)[!is.na(res.dynsim$meanSQ2[,1])]
	 else
	  ind <- window   
      if(is.null(res.dynsim3$meanSQ2))
	 {
        matplot(cbind(ind,ind,ind),res.dynsim$meanSQ2[ind,],
                type="l",lty=c(1,2,2),col=par.col[1],lwd=1.5,xlab="Time",ylab="mean SQt-1",ylim=meanSQ2.lim,main=main)
        if(!is.null(meanSQ2))
          lines(1:n,meanSQ2,col=1)
        if(!is.null(res.dynsim2$meanSQ2))
          {
	  if(is.null(window))
	    ind2 <- c(1:n)[!is.na(res.dynsim2$meanSQ2[,1])]
	  else
	    ind2 <- window
          matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanSQ2[ind2,],type="l",lwd=1.5,lty=c(1,2,2),col=par.col[2])
          }
        }   
      else
	  {
	  if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$meanSQ2[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$meanSQ2[,1])]}
	  else{ind2 <- ind3 <- window}
	    if(!CI){
	  matplot(ind,res.dynsim$meanSQ2[ind,1],type="l",lty=1,col=par.col[1],lwd=1.5,xlab="Time",ylab="mean SQt-1",ylim=meanSQ2.lim,main=main)
	  matlines(ind2,res.dynsim2$meanSQ2[ind2,1],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(ind3,res.dynsim3$meanSQ2[ind3,1],type="l",lty=3,lwd=1.5,col=par.col[3])
	  if(!is.null(res.dynsim4$meanSQ2)) matlines(ind2,res.dynsim4$meanSQ2[ind2,1],type="l",lty=4,lwd=1.5,col=par.col[4]) 
	    }
	  else{
	  matplot(cbind(ind,ind,ind),res.dynsim$meanSQ2[ind,],type="l",lty=1,lwd=1.5,col=par.col[1],xlab="Time",ylab="mean SQt-1",ylim=meanSQ2.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanSQ2[ind2,],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$meanSQ2[ind3,],type="l",lty=3,lwd=1.5,col=par.col[3])	  
	    if(!is.null(res.dynsim4$meanSQ2)) matlines(ind2,res.dynsim4$meanSQ2[ind2,],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }	  
	  }
      }
      
    if(display.plot[6]==1)
      {
        n <- nrow(res.dynsim$meanT2)
	 if(is.null(window))
	  ind <- c(1:n)[!is.na(res.dynsim$meanT2[,1])]
	 else
	  ind <- window   
      if(is.null(res.dynsim3$meanT2))
	 {
        matplot(cbind(ind,ind,ind),res.dynsim$meanT2[ind,],
                type="l",lty=c(1,2,2),col=par.col[1],lwd=1.5,xlab="Time",ylab="mean Xt-1",ylim=meanT2.lim,main=main)
        if(!is.null(meanT2))
          lines(1:n,meanT2,col=1)
        if(!is.null(res.dynsim2$meanT2))
          {
	  if(is.null(window))
	    ind2 <- c(1:n)[!is.na(res.dynsim2$meanT2[,1])]
	  else
	    ind2 <- window
          matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanT2[ind2,],type="l",lwd=1.5,lty=c(1,2,2),col=par.col[2])
          }
        }   
      else
	  {
	  if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$meanT2[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$meanT2[,1])]}
	  else{ind2 <- ind3 <- window}
	  if(!CI){
	  matplot(ind,res.dynsim$meanT2[ind,1],type="l",lty=1,col=par.col[1],lwd=1.5,xlab="Time",ylab="mean Xt-1",ylim=meanT2.lim,main=main)
	  matlines(ind2,res.dynsim2$meanT2[ind2,1],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(ind3,res.dynsim3$meanT2[ind3,1],type="l",lty=3,lwd=1.5,col=par.col[3])
	    if(!is.null(res.dynsim4$meanT2)) matlines(ind2,res.dynsim4$meanT2[ind2,1],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }
	  else{
	  matplot(cbind(ind,ind,ind),res.dynsim$meanT2[ind,],type="l",lty=1,lwd=1.5,col=par.col[1],xlab="Time",ylab="mean Xt-1",ylim=meanT2.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$meanT2[ind2,],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$meanT2[ind3,],type="l",lty=3,lwd=1.5,col=par.col[3])	  
	    if(!is.null(res.dynsim4$meanT2)) matlines(ind2,res.dynsim4$meanT2[ind2,],type="l",lty=4,lwd=1.5,col=par.col[4]) 
	    }	  
	  }
      }
                 
    if(display.plot[7]==1)
      {
        n <- nrow(res.dynsim$alpha)
        if(is.null(window))
	   ind <- c(1:n)[!is.na(res.dynsim$alpha[,1])]
	else
	    ind <- window 
        if(is.null(res.dynsim3$alpha))
	  {
	  matplot(cbind(ind,ind,ind),res.dynsim$alpha[ind,],
                type="l",lty=c(1,2,2),col=par.col[1],lwd=1.5,xlab="Time",ylab=expression(alpha),ylim=alpha.lim,main=main)
	  if(!is.null(alpha))
	    abline(h=alpha)
	  if(!is.null(res.dynsim2$alpha))
	    {
          if(is.null(window))
	     ind2 <- c(1:n)[!is.na(res.dynsim2$alpha[,1])]
	  else
	      ind2 <- window 
            matlines(cbind(ind2,ind2,ind2),res.dynsim2$alpha[ind2,],type="l",lwd=1.5,lty=c(1,2,2),col=par.col[2])
	    }
	  }
        else
	  {
	  if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$alpha[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$alpha[,1])]}
	  else{ind2 <- ind3 <- window}
	    if(!CI){
	  matplot(ind,res.dynsim$alpha[ind,1],type="l",lty=1,col=par.col[1],lwd=1.5,xlab="Time",ylab=expression(alpha),ylim=alpha.lim,main=main)
	  matlines(ind2,res.dynsim2$alpha[ind2,1],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(ind3,res.dynsim3$alpha[ind3,1],type="l",lty=3,lwd=1.5,col=par.col[3])
	  if(!is.null(res.dynsim4$alpha)) matlines(ind2,res.dynsim4$alpha[ind2,1],type="l",lty=4,lwd=1.5,col=par.col[4]) 
	    }
	  else{
	    if(is.null(alpha.lim)) {alpha.lim[1] <- min(summary(res.dynsim$alpha[ind2,2])[[1]],summary(res.dynsim2$alpha[ind2,2])[[1]],summary(res.dynsim3$alpha[ind2,2])[[1]]) 
	  alpha.lim[2] <- max(summary(res.dynsim$alpha[ind2,3])[[6]],summary(res.dynsim2$alpha[ind2,3])[[6]],summary(res.dynsim3$alpha[ind2,3])[[6]])}
	  matplot(cbind(ind,ind,ind),res.dynsim$alpha[ind,],type="l",lty=1,col=par.col[1],lwd=1.5, xlab="Time",ylab=expression(alpha),ylim=alpha.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$alpha[ind2,],type="l",lwd=1.5,lty=2,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$alpha[ind3,],type="l",lwd=1.5,lty=3,col=par.col[3])	 
	    if(!is.null(res.dynsim4$alpha)) matlines(ind2,res.dynsim4$alpha[ind2,],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }	  
	  }
      }
          
    if(display.plot[8]==1)
      {
        n <- nrow(res.dynsim$phi)
        if(is.null(window))
	   ind <- c(1:n)[!is.na(res.dynsim$phi[,1])]
	else
	    ind <- window 
      if(is.null(res.dynsim3$phi))
	  {
        matplot(cbind(ind,ind,ind),res.dynsim$phi[ind,],
                type="l",lty=c(1,2,2),lwd=1.5,col=par.col[1],xlab="Time",ylab=expression(phi),ylim=phi.lim,main=main)
        if(!is.null(phi))
          abline(h=phi)
        if(!is.null(res.dynsim2$phi))
          {
        if(is.null(window))
	  ind2 <- c(1:n)[!is.na(res.dynsim2$phi[,1])]
	else
	  ind2 <- window  
            matlines(cbind(ind2,ind2,ind2),res.dynsim2$phi[ind2,],type="l",lwd=1.5,lty=c(1,2,2),col=par.col[2])
          }
        }  
      else
	  {
	  if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$phi[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$phi[,1])]}
	  else{ind2 <- ind3 <- window}
	  if(!CI){
	    if(is.null(phi.lim)) {phi.lim[1] <- min(summary(res.dynsim$phi[ind2,1])[[1]],summary(res.dynsim2$phi[ind2,1])[[1]],summary(res.dynsim3$phi[ind2,1])[[1]]) 
	  phi.lim[2] <- max(summary(res.dynsim$phi[ind2,1])[[6]],summary(res.dynsim2$phi[ind2,1])[[6]],summary(res.dynsim3$phi[ind2,1])[[6]])}
	  matplot(ind,res.dynsim$phi[ind,1],type="l",lwd=1.5,lty=1,col=par.col[1],xlab="Time",ylab=expression(phi),ylim=phi.lim,main=main)
	  matlines(ind2,res.dynsim2$phi[ind2,1],type="l",lwd=1.5,lty=2,col=par.col[2])
	  matlines(ind3,res.dynsim3$phi[ind3,1],type="l",lty=3,lwd=1.5,col=par.col[3])
	  if(!is.null(res.dynsim4$phi)) matlines(ind2,res.dynsim4$phi[ind2,1],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }
	  else{
	    if(is.null(phi.lim)) {phi.lim[1] <- min(summary(res.dynsim$phi[ind2,2])[[1]],summary(res.dynsim2$phi[ind2,2])[[1]],summary(res.dynsim3$phi[ind2,2])[[1]]) 
	  phi.lim[2] <- max(summary(res.dynsim$phi[ind2,3])[[6]],summary(res.dynsim2$phi[ind2,3])[[6]],summary(res.dynsim3$phi[ind2,3])[[6]])}
	  matplot(cbind(ind,ind,ind),res.dynsim$phi[ind,],type="l",lty=1,lwd=1.5,col=par.col[1],xlab="Time",ylab=expression(phi),ylim=phi.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$phi[ind2,],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$phi[ind3,],type="l",lty=3,lwd=1.5,col=par.col[3])
	    if(!is.null(res.dynsim4$phi)) matlines(ind2,res.dynsim4$phi[ind2,],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }	  
	  }
      }       
    if(tau.inla && display.plot[9]==1)
      {
        n <- nrow(res.dynsim$tau.inla)
        if(is.null(window))
	   ind <- c(1:n)[!is.na(res.dynsim$tau.inla[,1])]
	else
	    ind <- window       
        if(is.null(res.dynsim3$tau.inla))
	 {
        matplot(cbind(ind,ind,ind),res.dynsim$tau.inla[ind,],
                type="l",lty=c(1,2,2),col=par.col[1],lwd=1.5,xlab="Time",ylab=expression(tau),ylim=tau.lim,main=main)
        if(!is.null(tau))
          abline(h=tau)
        if(!is.null(res.dynsim2$tau.inla))
          { 
          if(is.null(window))
	   ind2 <- c(1:n)[!is.na(res.dynsim2$tau.inla[,1])]
	 else
	    ind2 <- window; 
	    if(is.null(tau.lim)) {tau.lim[1] <- min(summary(res.dynsim$tau.inla[ind2,])[[1]],summary(res.dynsim2$tau.inla[ind2,])[[1]]) 
	    tau.lim[2] <- max(summary(res.dynsim$tau.inla[ind2,])[[6]],summary(res.dynsim2$tau.inla[ind2,])[[6]])}
            matlines(cbind(ind2,ind2,ind2),res.dynsim2$tau.inla[ind2,],type="l",lwd=1.5,lty=c(1,2,2),col=par.col[2])
          }
	}    
      else
	  {
	  if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$tau.inla[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$tau.inla[,1])]}
	  else{ind2 <- ind3 <- window}

	  if(!CI){
	    if(is.null(tau.lim)) {tau.lim[1] <- min(summary(res.dynsim$tau.inla[ind2,1])[[1]],summary(res.dynsim2$tau.inla[ind2,1])[[1]],summary(res.dynsim3$tau.inla[ind2,1])[[1]]) 
	  tau.lim[2] <- max(summary(res.dynsim$tau.inla[ind2,1])[[6]],summary(res.dynsim2$tau.inla[ind2,1])[[6]],summary(res.dynsim3$tau.inla[ind2,1])[[6]])}
	  matplot(ind,res.dynsim$tau.inla[ind,1],type="l",lty=1,lwd=1.5,col=par.col[1],xlab="Time",ylab=expression(tau),ylim=tau.lim,main=main)
	  matlines(ind2,res.dynsim2$tau.inla[ind2,1],type="l",lty=2,col=par.col[2])
	  matlines(ind3,res.dynsim3$tau.inla[ind3,1],type="l",lty=3,col=par.col[3])
	  if(!is.null(res.dynsim4$tau.inla)) matlines(ind2,res.dynsim4$tau.inla[ind2,1],type="l",lty=4,col=par.col[4]) 
	    }
	  else{
	    if(is.null(tau.lim)) {tau.lim[1] <- min(summary(res.dynsim$tau.inla[ind2,2])[[1]],summary(res.dynsim2$tau.inla[ind2,2])[[1]],summary(res.dynsim3$tau.inla[ind2,2])[[1]]) 
	  tau.lim[2] <- max(summary(res.dynsim$tau.inla[ind2,3])[[6]],summary(res.dynsim2$tau.inla[ind2,3])[[6]],summary(res.dynsim3$tau.inla[ind2,3])[[6]])}
	  matplot(cbind(ind,ind,ind),res.dynsim$tau.inla[ind,],type="l",lty=1,lwd=1.5,col=par.col[1],xlab="Time",ylab=expression(tau),ylim=tau.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$tau.inla[ind2,],type="l",lwd=1.5,lty=2,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$tau.inla[ind3,],type="l",lty=3,lwd=1.5,col=par.col[3])	
	    if(!is.null(res.dynsim4$tau.inla)) matlines(ind2,res.dynsim4$tau.inla[ind2,],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }	  
	  }
	}
      else
	  {
          if(display.plot[9]==1)
	    {
        n <- nrow(res.dynsim$tau)
        if(is.null(window))
	   ind <- c(1:n)[!is.na(res.dynsim$tau[,1])]
	else
	    ind <- window       
        if(is.null(res.dynsim3$tau))
	 {
        matplot(cbind(ind,ind,ind),res.dynsim$tau[ind,],
                type="l",lty=c(1,2,2),col=par.col[1],lwd=1.5,xlab="Time",ylab=expression(tau),ylim=tau.lim,main=main)
        if(!is.null(tau))
          abline(h=tau)
        if(!is.null(res.dynsim2$tau))
          { 
          if(is.null(window))
	   ind2 <- c(1:n)[!is.na(res.dynsim2$tau[,1])]
	 else
	    ind2 <- window; 
	    if(is.null(tau.lim)) {tau.lim[1] <- min(summary(res.dynsim$tau[ind2,])[[1]],summary(res.dynsim2$tau[ind2,])[[1]]) 
	    tau.lim[2] <- max(summary(res.dynsim$tau[ind2,])[[6]],summary(res.dynsim2$tau[ind2,])[[6]])}
            matlines(cbind(ind2,ind2,ind2),res.dynsim2$tau[ind2,],type="l",lwd=1.5,lty=c(1,2,2),col=par.col[2])
          }
	}    
      else
	  {
	  if(is.null(window)){
	     ind2 <- c(1:n)[!is.na(res.dynsim2$tau[,1])];ind3 <- c(1:n)[!is.na(res.dynsim3$tau[,1])]}
	  else{ind2 <- ind3 <- window}

	  if(!CI){
	    if(is.null(tau.lim)) {tau.lim[1] <- min(summary(res.dynsim$tau[ind2,1])[[1]],summary(res.dynsim2$tau[ind2,1])[[1]],summary(res.dynsim3$tau[ind2,1])[[1]]) 
	  tau.lim[2] <- max(summary(res.dynsim$tau[ind2,1])[[6]],summary(res.dynsim2$tau[ind2,1])[[6]],summary(res.dynsim3$tau[ind2,1])[[6]])}
	  matplot(ind,res.dynsim$tau[ind,1],type="l",lty=1,col=par.col[1],lwd=1.5,xlab="Time",ylab=expression(tau),ylim=tau.lim,main=main)
	  matlines(ind2,res.dynsim2$tau[ind2,1],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(ind3,res.dynsim3$tau[ind3,1],type="l",lty=3,lwd=1.5,col=par.col[3])
	  if(!is.null(res.dynsim4$tau)) matlines(ind2,res.dynsim4$tau[ind2,1],type="l",lwd=1.5,lty=4,col=par.col[4]) 
	    }
	  else{
	    if(is.null(tau.lim)) {tau.lim[1] <- min(summary(res.dynsim$tau[ind2,2])[[1]],summary(res.dynsim2$tau[ind2,2])[[1]],summary(res.dynsim3$tau[ind2,2])[[1]]) 
	  tau.lim[2] <- max(summary(res.dynsim$tau[ind2,3])[[6]],summary(res.dynsim2$tau[ind2,3])[[6]],summary(res.dynsim3$tau[ind2,3])[[6]])}
	  matplot(cbind(ind,ind,ind),res.dynsim$tau[ind,],type="l",lty=1,col=par.col[1],lwd=1.5,xlab="Time",ylab=expression(tau),ylim=tau.lim,main=main)
	  matlines(cbind(ind2,ind2,ind2),res.dynsim2$tau[ind2,],type="l",lty=2,lwd=1.5,col=par.col[2])
	  matlines(cbind(ind3,ind3,ind3),res.dynsim3$tau[ind3,],type="l",lty=3,lwd=1.5,col=par.col[3])	
	    if(!is.null(res.dynsim4$tau)) matlines(ind2,res.dynsim4$tau[ind2,],type="l",lty=4,lwd=1.5,col=par.col[4]) 
	    }	  
	  }
	}
      }
      
#    par(par.save)
    invisible(0)
  }
