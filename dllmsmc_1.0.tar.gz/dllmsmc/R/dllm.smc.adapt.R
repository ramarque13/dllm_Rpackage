dllm.smc.adapt <- function(y,obsmodel="lingauss",
                    alphaprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                    phiprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                    tauprior=list(shape=1,rate=0.001,initial=1,fixed=FALSE),
                    N=1000,b=NULL,start.mcmc=list(m=10,nthin=1,burnin=N)) 
{
  if(obsmodel=="lingauss")
    dlogobsmod <- dllm.dlogmodlin
  else if(obsmodel=="svmodel")
    dlogobsmod <- dllm.dlogmodsv
  else if(obsmodel=="Poisson")
    dlogobsmod <- dllm.dlogmodpois
  else
    {
      print("Invalid observation model")
      return(NULL)
    }
   
  # particle block sampling, phi unknown 
  n <- length(y)
  if(is.null(b))
    b <- n+1    #Corresponds to no blocking
  X <- matrix(,n,N)
  Suff  <- matrix(0,5,N)
  Sparticle <- matrix(0,2,N);
  alpha <- array(NA,c(n,N))
  phi <- array(NA,c(n,N))
  tau <- array(NA,c(n,N))
  meanT <- array(NA,c(n,N))
  meanSQ <- array(NA,c(n,N))
  meanC <- array(NA,c(n,N))

  m <- start.mcmc$m
  #Simulate hyperparameters and X by MCMC
  res <- dllm.bugs(y[1:start.mcmc$m],obsmodel, alphaprior,phiprior,tauprior,N=N,
                   burnin=start.mcmc$burnin,nthin=start.mcmc$nthin)
  #Extract X
  X[1:m,] = res$X
  #Calculate sufficient statistics, neglecting first time point
  Suff.XX <- rep(0,N)
  Suff.XZ <- matrix(0,2,N)
  Suff.ZZ <-  array(0,c(2,2,N))
  
  for(s in 2:m)
    {
      Suff.XX <- Suff.XX + X[s,]^2
      Suff.XZ <- Suff.XZ + rbind(X[s,],X[s,]*X[s-1,])
      Suff.ZZ[1,,] <- Suff.ZZ[1,,] + rbind(1,X[s-1,])
      Suff.ZZ[2,,] <- Suff.ZZ[2,,] + rbind(X[s-1,],X[s-1,]^2)
    }
  numT <- m-1
  #Extract parameter estimates
  if(!alphaprior$fixed)
    {
      alpha[m,] <- res$alpha
    }
  if(!phiprior$fixed)
    {
      phi[m,] <- res$phi
    }
  if(!tauprior$fixed)
    {
      tau[m,] <- res$tau
    }
  #Put global sufficient statistics to 0
  Sparticle.XX <- Suff.XX*0
  Sparticle.XZ <- Suff.XZ*0
  Sparticle.ZZ <- Suff.ZZ*0

  meanT[m,]  <- Suff.XZ[1,]/(m-1)
  meanSQ[m,] <- Suff.XX/(m-1)
  meanC[m,]  <- Suff.XZ[2,]/(m-1)
  meanT2 <- res$meanT
  meanSQ2 <- res$meanSQ
  meanC2 <- res$meanC

  ind1 <- 1:N
  indM <- ind1
  for(s in 2:m)
    indM <- rbind(indM,ind1)
  timesinceblock <- 0

  #Simulate hyperparameters from posterior given X_{1:s-1}
  s <- m
  res <- dllm.hyperparsim(numT,N,Sparticle.XX+Suff.XX,Sparticle.XZ+Suff.XZ,
                          Sparticle.ZZ+Suff.ZZ,tauprior,alphaprior,phiprior)
  alpha[s,] <- res$beta[1,]
  phi[s,] <- res$beta[2,]
  tau[s,] <- res$tau
  
  #Iteration over remaining time points
  for(s in (m+1):n) 
    {
      if(s%%200==0)
        print(s)

      #Calculating importance distributions
      imp.dist <- dllm.calc.imp.dist(alpha[s-1,] + phi[s-1,]*(X[s-1,]-alpha[s-1,]),1/tau[s-1,],y[s],obsmodel)
      #Simulating X[s]
      X[s,] <- rnorm(N,imp.dist$mu,sqrt(imp.dist$sig2))
        
      #Update sufficient statistics
      if(s%%b!=0)
        {
          Suff.XX <- Suff.XX + X[s,]^2
          Suff.XZ <- Suff.XZ + rbind(X[s,],X[s,]*X[s-1,])
          Suff.ZZ[1,,] <- Suff.ZZ[1,,] + rbind(1,X[s-1,])
          Suff.ZZ[2,,] <- Suff.ZZ[2,,] + rbind(X[s-1,],X[s-1,]^2)
          numT <- numT + 1
        }
      
      #Calculating importance weights
      w <- dlogobsmod(y[s],X[s,])+dnorm(X[s,],alpha[s-1,]+phi[s-1,]*(X[s-1,]-alpha[s-1,]),1/sqrt(tau[s-1,]),log=TRUE) -
           dnorm(X[s,],imp.dist$mu,sqrt(imp.dist$sig2))
      w <- exp(w-max(w))
      w <- w/sum(w)
      #Effective sample size
      NESS <- 1/sum(w^2)
      
      #Resampling
      ind <- sample(1:N,N,replace=TRUE,prob=w)
      X[(s-1):s,] <- X[(s-1):s,ind]
      ind1 <- ind1[ind]
      indM <- rbind(indM,ind1)
#      if(s%%b!=0)
        {
          #Also resample sufficient statistics
          Suff.XX <- Suff.XX[ind]
          Suff.XZ <- Suff.XZ[,ind]
          Suff.ZZ <- Suff.ZZ[,,ind]
        }
      
      if(length(unique(ind1)) < (0.1*N) & timesinceblock > b)
        {
          cat(paste("Blocking at time",s,"\n"))
          Sparticle.XX <- Sparticle.XX + Suff.XX
          Sparticle.XZ <- Sparticle.XZ + Suff.XZ
          Sparticle.ZZ <- Sparticle.ZZ + Suff.ZZ
          Suff.XX <- Suff.XX*0
          Suff.XZ <- Suff.XZ*0
          Suff.ZZ <- Suff.ZZ*0
          ind1 <- 1:N
          timesinceblock <- -1
        }
      meanT[s,] <- (Sparticle.XZ[1,]+Suff.XZ[1,])/numT
      meanSQ[s,] <- (Sparticle.XX+Suff.XX)/numT
      meanC[s,] <- (Sparticle.XZ[2,]+Suff.XZ[2,])/numT

  #Simulate hyperparameters from posterior given X_{1:s-1}
      res <- dllm.hyperparsim(numT,N,Sparticle.XX+Suff.XX,Sparticle.XZ+Suff.XZ,
                              Sparticle.ZZ+Suff.ZZ,tauprior,alphaprior,phiprior)
      alpha[s,] <- res$beta[1,]
      phi[s,] <- res$beta[2,]
      tau[s,] <- res$tau
      timesinceblock <- timesinceblock + 1
     }
  res <- list(X=X,alpha=alpha,phi=phi,tau=tau,meanT=meanT,meanSQ=meanSQ,meanC=meanC,start=m,Suff.XX=Suff.XX,Suff.XZ=Suff.XZ,Suff.ZZ=Suff.ZZ,indM=indM)
  class(res) <- "dllmsmc"
  res
}
