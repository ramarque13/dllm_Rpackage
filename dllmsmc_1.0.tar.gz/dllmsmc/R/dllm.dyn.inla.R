dllm.dyn.inla <- function(y,obsmodel="lingauss",prec.y=1,
                     alphaprior=list(mu=0,prec=0.00001,initial=0,fixed=FALSE),
                     rhoprior=list(mu=0,prec=0.0001,initial=5,fixed=FALSE),
                     mtauprior=list(shape=1,rate=0.0001,initial=5,fixed=FALSE),
                     thin=1,numit=1,start=100)
{
   n <- length(y);

   fam <- "gaussian"; theta1 = log(prec.y)
   contr.fam <- list(hyper = list(prec = list(initial=theta1,fixed=TRUE)))
   if(obsmodel=="svmodel")
     {
       fam <- "stochvol"
       contr.fam <- list()
     }
   if(obsmodel=="Poisson")
     {
       fam <- "poisson"
       contr.fam <- list()
     }
   Mpar <- array(NA,c(n,5,3))
   for(i in start:n)
     {
     if(i%%thin==0)
        {
          print(i)
          d.inla <- list(y=y[1:i],time=1:i)
          #Robust version of inla, calling several times with changing priors
          meanT <- inla.make.lincomb(time=rep(1/i,i));names(meanT) <- "meanT"
          res.inla <- inla(y~1+f(time,model="ar1",
                                 hyper=list(theta1=list(param=c(mtauprior$shape,1),initial=mtauprior$initial,fixed=mtauprior$fixed),
                                   theta2=list(param=c(rhoprior$mu,1),initial=rhoprior$initial,fixed=rhoprior$fixed))),
                           control.fixed = list(mean.intercept=alphaprior$mu,prec.intercept = alphaprior$prec),
                           family=fam,data=d.inla,control.family=contr.fam)
          for(j in 1:numit)
            {
              if(!rhoprior$fixed)  
		init.rho <- log(1.1+res.inla$summary.hyperpar[2,6])-log(1.1-res.inla$summary.hyperpar[2,6])
	      else
	        init.rho <- rhoprior$initial  
              if(!mtauprior$fixed) 
		init.mtau <- log(res.inla$summary.hyperpar[1,6])
	      else
	        init.mtau <- mtauprior$initial
              
              #print(c(j,init.mtau,init.rho,res.inla$summary.hyperpar[2,6]))
              res.inla <- inla(y~1+f(time,model="ar1",hyper=list(
                                                        theta1=list(param=c(mtauprior$shape,mtauprior$rate^(j/numit)),initial=init.mtau,fixed=mtauprior$fixed),
                                                        theta2=list(param=c(rhoprior$mu,rhoprior$prec^(j/numit)),initial=init.rho))),
                               control.fixed = list(mean.intercept=alphaprior$mu,prec.intercept = alphaprior$prec),
                               family=fam,data=d.inla,control.family=contr.fam)
            }
          res.inla <- inla(y~1+f(time,model="ar1",hyper=list(
                                                    theta1=list(param=c(mtauprior$shape,mtauprior$rate^(j/numit)),initial=init.mtau,fixed=mtauprior$fixed),
                                                    theta2=list(param=c(rhoprior$mu,rhoprior$prec^(j/numit)),initial=init.rho,fixed=rhoprior$fixed))),
                           control.fixed = list(mean.intercept=alphaprior$mu,prec.intercept = alphaprior$prec),
                           family=fam,data=d.inla,control.family=contr.fam,lincomb=meanT,
			   control.inla=list(strategy="simplified.laplace"))
        
          #print(summary(res.inla))
        
          Mpar[i,1,1] <- res.inla$summary.random$time[i,2]
          Mpar[i,1,2] <- res.inla$summary.random$time[i,4]
          Mpar[i,1,3] <- res.inla$summary.random$time[i,6]
                     
          #Mpar[i,2,] <- res.inla$summary.fixed[c(1,3,5)]           
          Mpar[i,2,1] <- res.inla$summary.fixed[1,1]
          Mpar[i,2,2] <- res.inla$summary.fixed[1,3]
          Mpar[i,2,3] <- res.inla$summary.fixed[1,5]
   
            
          if(!rhoprior$fixed){
	    if(!mtauprior$fixed){
	    #Mpar[i,4,]  <- res.inla$summary.hyperpar[2,c(1,3,5)]
	    Mpar[i,4,1]  <- res.inla$summary.hyperpar[2,1]
	    Mpar[i,4,2]  <- res.inla$summary.hyperpar[2,3]
	    Mpar[i,4,3]  <- res.inla$summary.hyperpar[2,5]
	      }
            else{
	    #Mpar[i,4,]  <- res.inla$summary.hyperpar[2,c(1,3,5)]
	    Mpar[i,4,1]  <- res.inla$summary.hyperpar[1,1]
	    Mpar[i,4,2]  <- res.inla$summary.hyperpar[1,3]
	    Mpar[i,4,3]  <- res.inla$summary.hyperpar[1,5]
	      }        
           }
           else
	     Mpar[i,4,1] <- Mpar[i,4,2] <- Mpar[i,4,3] <- rhoprior$initial
	     
	  if(!mtauprior$fixed){        
	    #Mpar[i,3,] <-  res.inla$summary.hyperpar[1,c(1,3,5)]
	    Mpar[i,3,1] <- res.inla$summary.hyperpar[1,1]
	    Mpar[i,3,2] <- res.inla$summary.hyperpar[1,3]
	    Mpar[i,3,3] <- res.inla$summary.hyperpar[1,5]
	    
	    if(0){  
	    print(summary(res.inla))	    
	    print(names(res.inla$marginals.hy))
	    	    
	    Mpar[i,3,1]  <- inla.emarginal(function(x) 1/x, res.inla$marginals.hy[[1]])	    
	    tmarg        <- inla.tmarginal(function(x) 1/x, res.inla$marginals.hy[[1]])
	    CI           <- inla.hpdmarginal(0.975,tmarg)
	    Mpar[i,3,2]  <- CI[1]; Mpar[i,3,3] <- CI[2]
	    
	    print(Mpar[i,3,])
	    print("using summary")
	    print(res.inla$summary.hyperpar[1,1]/(1-Mpar[i,4,1]^2))
	    }
	    	    
	    }
          else
	    Mpar[i,3,1] <- Mpar[i,3,2] <- Mpar[i,3,3] <- mtauprior$initial
          
          Mpar[i,5,1] <- res.inla$summary.lincomb.derived[1,2]
          Mpar[i,5,2] <- res.inla$summary.lincomb.derived[1,4]
          Mpar[i,5,3] <- res.inla$summary.lincomb.derived[1,6]
        }
   }
   res <- list(X=Mpar[,1,],alpha=Mpar[,2,],phi=Mpar[,4,],tau=Mpar[,3,],meanT=Mpar[,5,])
   res$res.inla <- res.inla
   #class(res) <- "dllmdynsim" 
   class(res) <- "dllmsmc"
   res
}
