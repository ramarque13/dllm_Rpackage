dllm.calc.imp.dist <- function(mu,sig2,y,obsmodel)
  {
    if(obsmodel=="lingauss")
      {
        tau <- 1/sig2
        r <- sig2/(sig2+1)
        mu.post <- (1-r)*mu+r*y
        sig2.post <- sig2/(1+sig2)
      }
#     else if(obsmodel=="Poisson")
#       {
#         tau <- 1/sig2
#         mu.post <- mu
#         for(i in 1:10)
#           {
#             grad1 <- -tau*(mu.post-mu)+y-exp(mu.post)
#             grad2 <- tau+exp(mu.post)
#             mu.post <- mu.post + grad1/grad2
#           }
#         sig2.post <- 1/(tau+exp(mu.post))
#       }
      else
	{
	mu.post<-mu; sig2.post<-sig2
	}
    list(mu=mu.post,sig2=sig2.post)
  }
