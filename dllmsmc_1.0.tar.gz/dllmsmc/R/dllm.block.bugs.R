dllm.block.bugs <- function(y,obsmodel="lingauss",
                     alphaprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     phiprior=list(mu=0,prec=0.0001,initial=0,fixed=FALSE),
                     tauprior=list(shape=1,rate=0.001,initial=1,fixed=FALSE),
                     tau0=0.0001,
                     N=1000,b=NULL,b.initial=NULL,bugs=TRUE,start.mcmc=list(m=10,nthin=1,burnin=N),
                     seed=3245) 
{

  if(alphaprior$fixed)
    alphaprior2 <- c(alphaprior$initial,10000,1)
  else
    alphaprior2 <- c(alphaprior$mu,alphaprior$prec,0)
 if(phiprior$fixed)
    phiprior2 <- c(phiprior$initial,10000,1)
  else
    phiprior2 <- c(phiprior$mu,phiprior$prec,0)
  if(tauprior$fixed)
    tauprior2 <- c(tauprior$initial,10000,1)
  else
    tauprior2 <- c(tauprior$shape,tauprior$rate,0)
  set.seed(seed)
#   if(obsmodel=="lingauss")
#     dlogobsmod <- dllm.dlogmodlin
#   else if(obsmodel=="svmodel")
#     dlogobsmod <- dllm.dlogmodsv
#   else if(obsmodel=="Poisson")
#     dlogobsmod <- dllm.dlogmodpois
#   else
#     {
#       print("Invalid observation model")
#       return(NULL)
#     }
   
  n <- length(y)
  if(is.null(b))
    b <- n+1    #Corresponds to no blocking
  if(is.null(b.initial))
    b.initial <- 1
  X <- matrix(,n,N)
  alpha <- array(NA,c(n,N));  phi <- array(NA,c(n,N))
  tau <- array(NA,c(n,N));    meanT <- array(NA,c(n,N))
  meanSQ <- array(NA,c(n,N)); meanC <- array(NA,c(n,N))
  meanDiff <- array(NA,c(n,N)); meanT2 <- array(NA,c(n,N)); meanSQ2 <- array(NA,c(n,N))
  m <- start.mcmc$m
  #Simulate hyperparameters and X by MCMC

  nblock = n/b
  Suff.X <- matrix(0,6,N)
  
  for(j in 1:nblock)
      {
     print("Call Rbugs...") 
     res <- dllm.bugs(y[1:n],obsmodel,alphaprior,phiprior,tauprior,N=N,burnin=start.mcmc$burnin,nthin=start.mcmc$nthin)
     
     b.initial <- (j-1)*b + 1  
     b.end     <- j*b
     X[b.initial:b.end,] = res$X[b.initial:b.end,]  
     
    if(j==1) b.initial = 2  
    for(s in b.initial:b.end)
      {
      Suff.X[1,] <- Suff.X[1,] + 1
      Suff.X[2,] <- Suff.X[2,] + X[s,]
      Suff.X[3,] <- Suff.X[3,] + X[s,]^2
      Suff.X[4,] <- Suff.X[4,] + X[s-1,]
      Suff.X[5,] <- Suff.X[5,] + X[s,]*X[s-1,]
      Suff.X[6,] <- Suff.X[6,] + X[s-1,]^2
      
      meanT[s,]    <- Suff.X[2,]/Suff.X[1,]
      meanSQ[s,]   <- Suff.X[3,]/Suff.X[1,]
      meanC[s,]    <- Suff.X[5,]/Suff.X[1,]
      meanDiff[s,] <- Suff.X[5,]/Suff.X[6,]
      meanT2[s,]   <- Suff.X[4,]/Suff.X[1,]
      meanSQ2[s,]  <- Suff.X[6,]/Suff.X[1,]
      
      res <- dllm.hyperparsim(Suff.X,tauprior2,alphaprior2,phiprior2,sample(1:10^6,1))
      alpha[s,] <- res$alpha
      phi[s,] <- res$phi
      tau[s,] <- res$tau 
      }
    }
  res <- list(X=X,alpha=alpha,phi=phi,tau=tau,meanT=meanT,meanSQ=meanSQ,meanC=meanC,meanDiff=meanDiff,meanT2=meanT2,meanSQ2=meanSQ2,start=m,Suff.X=Suff.X)
  class(res) <- "dllmsmc"
  res
}
