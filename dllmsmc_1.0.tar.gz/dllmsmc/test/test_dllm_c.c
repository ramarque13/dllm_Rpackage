#include "dllm.h"

void dllm_hyperpar_sim(int *i_nT,int *i_N,
		       double *i_Suff_XX,double *i_Suff_XZ,double *i_Suff_ZZ,
		       double *i_prior_alpha,double *i_prior_phi,double *i_prior_tau,
		       int *i_seed,
		       double *o_alpha,double *o_phi,double *o_tau);

void dllm_mcmc(int *i_nT,int *i_burnin,int *i_N,int *i_thin,
	       double *i_y,int *i_seed,int *i_obsmodel,
	       double *i_prior_alpha,double *i_prior_phi,double *i_prior_tau,
	       double *o_x,double *o_alpha,double *o_phi,double *o_tau);

main()
{
  int       i,m,t,nT=10,burnin=10,N=20,nthin=2,seed=3245,obsmodel=0;
  double   *prior_alpha, *prior_phi, *prior_tau;
  double   *XX, *XZ, *ZZ;
  double   *x, *y, *alpha, *phi,*tau;
  FILE     *unit;

  prior_alpha = Mmatrix_1d(0,1,sizeof(double),1);
  prior_phi = Mmatrix_1d(0,1,sizeof(double),1);
  prior_tau = Mmatrix_1d(0,1,sizeof(double),1);

  prior_alpha[0] = 0.0;
  prior_alpha[1] = 0.0001;
  prior_phi[0] = 0.0;
  prior_phi[1] = 0.0001;
  prior_tau[0] = 1.0;
  prior_tau[1] = 0.001;

  XX = Mmatrix_1d(0,N,sizeof(double),1);
  XZ = Mmatrix_1d(0,N*2,sizeof(double),1);
  ZZ = Mmatrix_1d(0,N*4,sizeof(double),1);

  x = Mmatrix_1d(0,N*nT,sizeof(double),1);
  y = Mmatrix_1d(0,nT,sizeof(double),1);
  alpha = Mmatrix_1d(0,N,sizeof(double),1);
  phi = Mmatrix_1d(0,N,sizeof(double),1);
  tau = Mmatrix_1d(0,N,sizeof(double),1);

  for(i=0;i<N;i++)
    {
      XX[i] = 17.58533;
      XZ[i*2] = 0.218007;
      XZ[i*2+1] = 5.613006;
      ZZ[i*4] = 20.0;
      ZZ[i*4+1] = 1.514582;
      ZZ[i*4+2] = 1.514582;
      ZZ[i*4+3] = 16.42138;
    }
  
  /* Reading data */
  unit = fopen("data.txt","r");
  for(t=0;t<nT;t++)
    fscanf(unit,"%lf",&y[t]);
  fclose(unit);

  dllm_hyperpar_sim(&nT,&N,XX,XZ,ZZ,
	    prior_alpha,prior_phi,prior_tau,
	    &seed,alpha,phi,tau);

  dllm_mcmc(&nT,&burnin,&N,&nthin,y,&seed,&obsmodel,
	    prior_alpha,prior_phi,prior_tau,
	    x,alpha,phi,tau);

  unit = fopen("hyperpar_sim.txt","w");
  for(t=0;t<N;t++)
    fprintf(unit,"%lf %lf %lf\n",alpha[t],phi[t],tau[t]);
  fclose(unit);

  unit = fopen("x_sim.txt","w");
  for(m=0;m<N;m++)
    {
      for(t=0;t<nT;t++)
	fprintf(unit,"%lf ",x[m*nT+t]);
      fprintf(unit,"\n");
    }
  fclose(unit);


  Fmatrix_1d(XX);
  Fmatrix_1d(XZ);
  Fmatrix_1d(ZZ);
  Fmatrix_1d(x);
  Fmatrix_1d(y);
  Fmatrix_1d(alpha);
  Fmatrix_1d(phi);
  Fmatrix_1d(tau);
  Fmatrix_1d(prior_alpha);
  Fmatrix_1d(prior_phi);
  Fmatrix_1d(prior_tau);

  exit(0);
}
