#include "dllm.h"
gsl_rng *dllm_gsl_rng;
void dllm_hyperpar_sim(int *i_N,double *i_Suff_X,
		       double *i_prior_alpha,double *i_prior_phi,double *i_prior_tau,
		       int *i_seed,
		       double *o_alpha,double *o_phi,double *o_tau)
{
  int           err,i,p=2;
  int           N;
  double        XX,alpha,phi,tau;
  unsigned long int seed;
  gsl_vector   *XZ, *prior_mu, *prior_prec;
  gsl_matrix   *ZZ;
  gsl_rng      *dllm_gsl_rng;

  XZ = gsl_vector_alloc(p);
  ZZ = gsl_matrix_alloc(p,p);
  prior_mu = gsl_vector_alloc(p);
  prior_prec = gsl_vector_alloc(p);

  seed = *i_seed;
  dllm_gsl_rng = gsl_rng_alloc(gsl_rng_mt19937);
  gsl_rng_set(dllm_gsl_rng,seed);
  N = *i_N;
  gsl_vector_set(prior_mu,0,i_prior_alpha[0]);
  gsl_vector_set(prior_mu,1,i_prior_phi[0]);
  gsl_vector_set(prior_prec,0,i_prior_alpha[1]);
  gsl_vector_set(prior_prec,1,i_prior_phi[1]);


  for(i=0;i<N;i++)
    {
      XX = i_Suff_X[i*6+2];
      gsl_vector_set(XZ,0,i_Suff_X[i*6+1]);
      gsl_vector_set(XZ,1,i_Suff_X[i*6+4]);
      gsl_matrix_set(ZZ,0,0,i_Suff_X[i*6]);
      gsl_matrix_set(ZZ,0,1,i_Suff_X[i*6+3]);
      gsl_matrix_set(ZZ,1,0,i_Suff_X[i*6+3]);
      gsl_matrix_set(ZZ,1,1,i_Suff_X[i*6+5]);
      err = dllm_sim_hyperpar(p,prior_mu,prior_prec,i_prior_tau,XX,XZ,ZZ,
			      dllm_gsl_rng,&alpha,&phi,&tau);
      o_alpha[i] = alpha;
      o_phi[i] = phi;
      o_tau[i] = tau;
      #ifdef DEBUG
      if(i==0)
	{
	  fprintf(stderr,"XX=%lf,XZ=%lf %lf\n",XX,gsl_vector_get(XZ,0),gsl_vector_get(XZ,1));
	  fprintf(stderr,"ZZ=%lf %lf %lf %lf\n",
		  gsl_matrix_get(ZZ,0,0),gsl_matrix_get(ZZ,0,1),
		  gsl_matrix_get(ZZ,1,0),gsl_matrix_get(ZZ,1,1));
	  fprintf(stderr,"alpha=%lf,phi=%lf,tau=%lf\n",alpha,phi,tau);
	}
      #endif
    }

  gsl_vector_free(XZ);
  gsl_matrix_free(ZZ);
  gsl_vector_free(prior_mu);
  gsl_vector_free(prior_prec);
  gsl_rng_free(dllm_gsl_rng);

  return;
}




