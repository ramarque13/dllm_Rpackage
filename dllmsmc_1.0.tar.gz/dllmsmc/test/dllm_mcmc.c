#include "dllm.h"

void dllm_mcmc_print_input(int *i_nT,int *i_burnin,int *i_N,int *i_thin,
			   double *i_y,int *i_seed,int *i_obsmodel,
			   double *i_tau0,
			   double *i_prior_alpha,double *i_prior_phi,double *i_prior_tau);
void dllm_mcmc_print_output(int N,double *i_alpha,double *i_phi,double *i_tau);

void dllm_mcmc(int *i_nT,int *i_burnin,int *i_N,int *i_thin,
	       double *i_y,int *i_seed,int *i_obsmodel,
	       double *i_tau0,
	       double *i_prior_alpha,double *i_prior_phi,double *i_prior_tau,
	       double *o_x,double *o_alpha,double *o_phi,double *o_tau)
{
  int           err,m,ind,t,p=2,obsmodel;
  int           nT, burnin, N,thin;
  unsigned long int seed;
  double        alpha,phi,tau,tau0, XX,dummy;
  gsl_vector   *x, *XZ, *prior_mu, *prior_prec;
  gsl_matrix   *ZZ;
  gsl_rng      *dllm_gsl_rng;

  dllm_mcmc_print_input(i_nT,i_burnin,i_N,i_thin,
			i_y,i_seed,i_obsmodel,
			i_tau0,i_prior_alpha,i_prior_phi,i_prior_tau);
  
  seed = *i_seed;
  dllm_gsl_rng = gsl_rng_alloc(gsl_rng_mt19937);
  gsl_rng_set(dllm_gsl_rng,seed);
  nT = *i_nT;
  burnin = *i_burnin;
  N = *i_N;
  thin = *i_thin;
  obsmodel = *i_obsmodel;
  tau0 = *i_tau0;
  //Allocation of space
  x = gsl_vector_alloc(nT);
  XZ = gsl_vector_alloc(p);
  ZZ = gsl_matrix_alloc(p,p);
  prior_mu = gsl_vector_alloc(p);
  prior_prec = gsl_vector_alloc(p);
  
  gsl_vector_set(prior_mu,0,i_prior_alpha[0]);
  gsl_vector_set(prior_mu,1,i_prior_phi[0]);
  gsl_vector_set(prior_prec,0,i_prior_alpha[1]);
  gsl_vector_set(prior_prec,1,i_prior_phi[1]);


  //Initialization
  alpha = 0.0;
  phi = 0.5;
  tau = 0.00001;
  for(t=0;t<nT;t++)
    gsl_vector_set(x,t,0);

  //MCMC
  alpha = gsl_ran_ugaussian(dllm_gsl_rng);
  #ifdef DEBUG
  FILE         *unit;
  unit = fopen("x_sim2.txt","w");
  #endif
  for(m=-burnin;m<(N*thin);m++)
    {
      if(obsmodel==0)
	err = dllm_sim_x_lin(nT,i_y,tau0,alpha,phi,tau,dllm_gsl_rng,x);
      //Calculate sufficient statistics
      err = dllm_calc_suff(nT,p,x,&XX,XZ,ZZ);
      //Simulate hyperparameters
      err = dllm_sim_hyperpar(p,prior_mu,prior_prec,i_prior_tau,XX,XZ,ZZ,
			      dllm_gsl_rng,&alpha,&phi,&tau);
      if(m>=0 && m%thin==0)	
	{
	  ind = (int) (m/thin);
	  for(t=0;t<nT;t++)
	    o_x[ind*nT+t] = gsl_vector_get(x,t);
	  o_alpha[ind] = alpha;
	  o_phi[ind] = phi;
	  o_tau[ind] = tau;
	  #ifdef DEBUG
	  fprintf(unit,"%d ",ind);
	  for(t=0;t<nT;t++)
	    fprintf(unit,"%lf ",gsl_vector_get(x,t));
	  fprintf(unit,"\n");
	  if(m==0)
	    {
	      fprintf(stderr,"x:");
	      for(t=0;t<nT;t++)
		fprintf(stderr,"%lf ",gsl_vector_get(x,t));
	      fprintf(stderr,"\n");
	    }
	  #endif
	}
    }
  #ifdef DEBUG
  fclose(unit);
  #endif

  dllm_mcmc_print_output(N,o_alpha,o_phi,o_tau);
      
  gsl_vector_free(x);
  gsl_vector_free(XZ);
  gsl_matrix_free(ZZ);
  gsl_vector_free(prior_mu);
  gsl_vector_free(prior_prec);
  gsl_rng_free(dllm_gsl_rng);

  return;
}


void dllm_mcmc_print_input(int *i_nT,int *i_burnin,int *i_N,int *i_thin,
			   double *i_y,int *i_seed,int *i_obsmodel,
			   double *i_tau0,
			   double *i_prior_alpha,double *i_prior_phi,double *i_prior_tau)
{
  int t;
  FILE *unit;
  
  unit = fopen("mcmc_input.txt","w");
  fprintf(unit,"nT=%d,burnin=%d,N=%d,thin=%d,seed=%d,obsmodel=%d\n",
	  *i_nT,*i_burnin,*i_N,*i_thin,*i_seed,*i_obsmodel);
  fprintf(unit,"y=");
  for(t=0;t<(*i_nT);t++)
    fprintf(unit,"%lf ",i_y[t]);
  fprintf(unit,"tau0=%lf\n",*i_tau0);
  fprintf(unit,"prior_alpha=%lf %lf\n",i_prior_alpha[0],i_prior_alpha[1]);
  fprintf(unit,"prior_phi=%lf %lf\n",i_prior_phi[0],i_prior_phi[1]);
  fprintf(unit,"prior_tau=%lf %lf\n",i_prior_tau[0],i_prior_tau[1]);
  fclose(unit);
}

void dllm_mcmc_print_output(int N,double *i_alpha,double *i_phi,double *i_tau)
{
  int i;
  FILE *unit;
  
  unit = fopen("mcmc_output.txt","w");
  for(i=0;i<N;i++)
    fprintf(unit,"%lf %lf %lf\n",i_alpha[i],i_phi[i],i_tau[i]);
  fclose(unit);
  
}
