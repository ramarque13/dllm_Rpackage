#include "dllm.h"
int dllm_sim_x_lin(int i_nT,double *i_y,double tau0,
		   double alpha,double phi,double tau,const gsl_rng *i_r,
		   gsl_vector *o_x)
{
  int     t;
  double  xpred,Ppred,S,K,A,mu,P,sig2,sig02;
  gsl_vector *xhat, *Phat;
  
  xhat = gsl_vector_alloc(i_nT);
  Phat = gsl_vector_alloc(i_nT);

  sig02 = G_ONE/tau0;
  sig2 = G_ONE/tau;
  // Run Kalman simulator
  xpred = alpha;
  Ppred = sig02;
  S = Ppred+G_ONE;
  K = Ppred/S;
  gsl_vector_set(Phat,0,(G_ONE-K)*Ppred);
  gsl_vector_set(xhat,0,xpred + K*(i_y[0]-xpred));
  for(t=1;t<i_nT;t++)
    {
      xpred = alpha+phi*(gsl_vector_get(xhat,t-1)-alpha);
      Ppred = phi*phi*gsl_vector_get(Phat,t-1)+sig2;
      S = Ppred+G_ONE;
      K = Ppred/S;
      gsl_vector_set(Phat,t,(G_ONE-K)*Ppred);
      gsl_vector_set(xhat,t,xpred + K*(i_y[t]-xpred));
    }
  gsl_vector_set(o_x,i_nT-1,gsl_vector_get(xhat,i_nT-1)+
		 gsl_ran_gaussian(i_r,sqrt(gsl_vector_get(Phat,i_nT-1))));
  for(t=i_nT-2;t>=0;t--)
    {
      xpred = alpha+phi*(gsl_vector_get(xhat,t)-alpha);
      Ppred = phi*phi*gsl_vector_get(Phat,t)+sig2;
      A = gsl_vector_get(Phat,t)*phi/Ppred;
      mu = gsl_vector_get(xhat,t)+A*(gsl_vector_get(o_x,t+1)-xpred);
      P = gsl_vector_get(Phat,t) * sig2/(phi*phi*gsl_vector_get(Phat,t)+sig2);
      gsl_vector_set(o_x,t,mu + sqrt(P)*gsl_ran_ugaussian(i_r));
    }

  gsl_vector_free(xhat);
  gsl_vector_free(Phat);
  return(0);
}

int dllm_calc_suff(int nT,int p,gsl_vector *i_x,double *o_XX,gsl_vector *o_XZ,gsl_matrix *o_ZZ)
{
  int     i,j,t;

  *o_XX = G_ZERO;
  for(i=0;i<p;i++)
    {
      gsl_vector_set(o_XZ,i,G_ZERO);
      for(j=0;j<p;j++)
	gsl_matrix_set(o_ZZ,i,j,G_ZERO);
    }
  for(t=1;t<nT;t++)
    {
      *o_XX += gsl_vector_get(i_x,t)*gsl_vector_get(i_x,t);
      gsl_vector_set(o_XZ,0,gsl_vector_get(o_XZ,0)+gsl_vector_get(i_x,t));
      gsl_vector_set(o_XZ,1,gsl_vector_get(o_XZ,1)+gsl_vector_get(i_x,t)*gsl_vector_get(i_x,t-1));
      gsl_matrix_set(o_ZZ,0,0,gsl_matrix_get(o_ZZ,0,0)+G_ONE);
      gsl_matrix_set(o_ZZ,0,1,gsl_matrix_get(o_ZZ,0,1)+gsl_vector_get(i_x,t-1));
      gsl_matrix_set(o_ZZ,1,1,gsl_matrix_get(o_ZZ,1,1)+gsl_vector_get(i_x,t-1)*gsl_vector_get(i_x,t-1));
    }
  gsl_matrix_set(o_ZZ,1,0,gsl_matrix_get(o_ZZ,0,1));
 
  return(0);
}


int dllm_sim_hyperpar(int i_p,gsl_vector *i_prior_mu,
		      gsl_vector *i_prior_prec,double *i_prior_tau,
		      double i_XX,gsl_vector *i_XZ,gsl_matrix *i_ZZ,
		      const gsl_rng *i_r,
		      double *o_alpha,double *o_phi,double *o_tau)
{
  int         err,i,j,t;
  double      a,b,detQ,muQmu,mubarQbarmubar,r,sigma;
  double      eps0,eps1;
  double      beta0,alpha,phi,tau;
  gsl_vector *mubar, *XZprior;
  gsl_matrix *Qbar, *Qchol;
#ifdef DEBUG
  FILE       *unit;
#endif

  mubar = gsl_vector_alloc(i_p);
  XZprior = gsl_vector_alloc(i_p);
  Qbar = gsl_matrix_alloc(i_p,i_p);
  Qchol = gsl_matrix_alloc(i_p,i_p);

#ifdef DEBUG
  unit = fopen("XX.dat","w");
  fprintf(unit,"%lf\n",i_XX);
  fclose(unit);
  
  unit = fopen("XZ.dat","w");
  for(i=0;i<2;i++)
    fprintf(unit,"%lf\n",gsl_vector_get(i_XZ,i));
  fclose(unit);

  unit = fopen("ZZ.dat","w");
  for(i=0;i<2;i++)
    fprintf(unit,"%lf %lf\n",gsl_matrix_get(i_ZZ,i,0),gsl_matrix_get(i_ZZ,i,1));
  fclose(unit);
#endif
  //Calculate Qbar=Q+sum z_tz_t' and XZprior=Q%*%mu + sum x_tz_t
  for(i=0;i<i_p;i++)
    {
      gsl_vector_set(XZprior,i,gsl_vector_get(i_XZ,i)+gsl_vector_get(i_prior_mu,i));
      gsl_matrix_set(Qbar,i,i,gsl_matrix_get(i_ZZ,i,i)+gsl_vector_get(i_prior_prec,i));
      for(j=0;j<i;j++)
	{
	  gsl_matrix_set(Qbar,i,j,gsl_matrix_get(i_ZZ,i,j));
	  gsl_matrix_set(Qbar,j,i,gsl_matrix_get(Qbar,i,j));
	}
    }

#ifdef DEBUG
  unit = fopen("XZprior.dat","w");
  for(i=0;i<2;i++)
    fprintf(unit,"%lf\n",gsl_vector_get(XZprior,i));
  fclose(unit);
  unit = fopen("Qbar.dat","w");
  for(i=0;i<2;i++)
    fprintf(unit,"%lf %lf\n",gsl_matrix_get(Qbar,i,0),gsl_matrix_get(Qbar,i,1));
  fclose(unit);
#endif

  //For p=2, should be made more general
  detQ = gsl_matrix_get(Qbar,0,0)*gsl_matrix_get(Qbar,1,1)-
         gsl_matrix_get(Qbar,0,1)*gsl_matrix_get(Qbar,0,1);
  gsl_vector_set(mubar,0,(gsl_matrix_get(Qbar,1,1)*gsl_vector_get(XZprior,0)-
			   gsl_matrix_get(Qbar,0,1)*gsl_vector_get(XZprior,1))/detQ);
  gsl_vector_set(mubar,1,(-gsl_matrix_get(Qbar,0,1)*gsl_vector_get(XZprior,0)+
			   gsl_matrix_get(Qbar,0,0)*gsl_vector_get(XZprior,1))/detQ);

  //Calculate mubar=Qbar^{-1}XZprior
  err = gsl_vector_memcpy(mubar,XZprior);
  err = gsl_linalg_cholesky_decomp(Qbar);
  gsl_linalg_cholesky_svx(Qbar,mubar);

#ifdef DEBUG

  unit = fopen("mubar.dat","w");
  for(i=0;i<2;i++)
    fprintf(unit,"%lf\n",gsl_vector_get(mubar,i));
  fclose(unit);
#endif
  
  muQmu = G_ZERO;
  mubarQbarmubar = G_ZERO;
  for(i=0;i<i_p;i++)
    {
      muQmu += gsl_vector_get(i_prior_mu,i)*gsl_vector_get(i_prior_prec,i)*
	gsl_vector_get(i_prior_mu,i);
      mubarQbarmubar += gsl_vector_get(XZprior,i)*gsl_vector_get(mubar,i);
    }

#ifdef DEBUG
  unit = fopen("muQmu.dat","w");
  fprintf(unit,"%lf %lf\n",muQmu,mubarQbarmubar);
  fclose(unit);

  unit = fopen("prior_tau.dat","w");
  fprintf(unit,"%lf %lf\n",i_prior_tau[0],i_prior_tau[1]);
  fclose(unit);
#endif
  
  
  a = i_prior_tau[0]+G_HALF*(gsl_matrix_get(i_ZZ,0,0) - (double) (i_p-1));
  b = i_prior_tau[1]+G_HALF*(muQmu+i_XX-mubarQbarmubar);
  tau = gsl_ran_gamma(i_r,a,G_ONE/b);
  sigma = 1/sqrt(tau);
  #ifdef DEBUG
  fprintf(stderr,"a=%lf,b=%lf,tau=%lf\n",a,b,tau);
  #endif

  eps0 = sigma*gsl_ran_ugaussian(i_r);
  eps1 = sigma*gsl_ran_ugaussian(i_r);

  phi = gsl_vector_get(mubar,1) + eps1/gsl_matrix_get(Qbar,1,1);
  beta0 = gsl_vector_get(mubar,0) + eps0/gsl_matrix_get(Qbar,0,0) - 
    eps1*gsl_matrix_get(Qbar,1,0)/(gsl_matrix_get(Qbar,0,0)*gsl_matrix_get(Qbar,1,1));
  alpha = beta0/(G_ONE-phi);

  gsl_vector_free(mubar);
  gsl_vector_free(XZprior);
  gsl_matrix_free(Qbar);
  gsl_matrix_free(Qchol);


  *o_alpha = alpha;
  *o_phi = phi;
  *o_tau = tau;

  return(0);
}
